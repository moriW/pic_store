import logging
from mico_spider import *


logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(levelname)s : %(message)s',
                    datefmt='%Y/%m/%d %H:%M:%S',)


def spider_guokr():
    with open('data/guokr', 'w') as guokr_file:
        for title, content in start_guokr():
            guokr_file.write(title + ',' + content + '\n')


def spider_sina_news():
    with open('data/sina_news', 'w') as sian_news_file:
        for title, content in start_sina_news():
            sian_news_file.write(title + ',' + content + '\n')


if __name__ == '__main__':
    spider_sina_news()
