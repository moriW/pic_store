import logging
import requests
import threading
from bs4 import BeautifulSoup
from typing import Iterable, Tuple

guokr_url = 'http://www.guokr.com/apis/minisite/article.json?retrieve_type=by_subject&offset={offset}&limit={limit}'
sian_news = 'http://api.roll.news.sina.com.cn/zt_list?channel=news&cat_1=gnxw&show_all=1&show_num={limit}&tag=1&format=json&page={offset}'

default_limit = 200


class GuokrSpider(threading.Thread):

    def __init__(self, url):
        threading.Thread.__init__(self)
        self.url = url

    def get_result(self) -> str:
        return self.result

    def spider_content(self):
        try:
            soup = BeautifulSoup(requests.get(self.url).text, 'lxml')
            content = soup.find(id='articleContent')
            return content.text
        except Exception as _:
            logging.error('Error escape this one: ' + self.url)
            return ''

    def run(self):
        self.result = self.spider_content()

    @classmethod
    def read_guokr_directory(cls) -> Iterable[Tuple[str, str]]:
        offset = 0
        limit = default_limit
        while True:
            logging.info('current page : %d , %d' % (offset, limit))
            url = guokr_url.format(offset=offset, limit=limit)
            try:
                result = requests.get(url).json()
            except Exception as _:
                logging.error('get directory failed retry')
                continue
            for article in result['result']:
                url = article['url']
                title = article['title']
                yield url, title
            if offset + limit > result['total']:
                break
            offset += limit


class SinaNewsSpider(threading.Thread):
    def __init__(self, url):
        threading.Thread.__init__(self)
        self.url = url

    def get_result(self):
        return self.result

    def run(self):
        self.result = self.spider_news()

    def spider_news(self):
        try:
            response = requests.get(self.url)
            response.encoding = 'UTF-8'
            soup = BeautifulSoup(response.text, 'lxml')
            content = soup.find(id='artibody')
            return content.text
        except Exception as _:
            logging.error('Error escape this one: ' + self.url)
            return ''

    @classmethod
    def read_sina_directory(cls):
        offset = 0
        limit = default_limit
        while True:
            logging.info(
                'current page : %d, %d' %
                (offset * limit, (offset + 1) * limit))
            url = sian_news.format(offset=offset, limit=limit)
            try:
                result = requests.get(url).json()
            except Exception as _:
                logging.error('get directory failed retry')
                continue
            for news in result['result']['data']:
                title = news['title']
                url = news['url']
                yield url, title
            if (offset + 1) * limit > int(result['result']['total']):
                break
            offset += 1


def start_guokr() -> Iterable[Tuple[str, str]]:
    max_run = 5
    threads = []
    for url, title in GuokrSpider.read_guokr_directory():
        spider = GuokrSpider(url)
        spider.start()
        threads.append(spider)
        if len(threads) == max_run:
            for spider in threads:
                spider.join()
                content = spider.get_result()
                yield title, content.replace('\n', '')
            threads.clear()


def start_sina_news() -> Iterable[Tuple[str, str]]:
    max_run = 200
    threads = []
    for url, title in SinaNewsSpider.read_sina_directory():
        spider = SinaNewsSpider(url)
        spider.start()
        threads.append(spider)
        if len(threads) == max_run:
            for spider in threads:
                spider.join()
                content = spider.get_result()
                yield title, content.replace('\n', '')
            threads.clear()
