 
//
//  main.cpp
//  simone牌文本编辑器
//
//  Created by Moridisa on 14-6-30.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;

int main()
{
    int loop;
    cin>>loop;
    while (loop--) {
        
        string a,b;
        cin>>a>>b;
        
        int sum=0;
        bool flag;
        
        for (size_t i=0; i!=a.size(); i++) {
            flag = false;
            if (a[i]==b[0]) {
                flag=true;
                //cout<<a[i]<<' '<<b[0]<<' ';
                for (size_t j=0; j!=b.size(); j++){
                    //cout<<a[i+j]<<' '<<b[j]<<' ';
                    if (a[i+j]!=b[j])
                        flag=false;
                }
            }
            
            if (flag)
                sum++;
            
        }
        cout<<sum<<endl;
    }
}        