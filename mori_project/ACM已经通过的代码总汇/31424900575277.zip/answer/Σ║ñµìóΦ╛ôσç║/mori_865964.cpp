 
#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    while(n!=0)
    {
        int a[n],i,t;
        for (i=0; i<n; i++)
            scanf("%d",&a[i]);
        t=0;
        for (i=1 ; i<n; i++)
        {
            if (a[t]>a[i])
            t=i;
        }
        if(t!=0){
            a[0]=a[0]+a[t];
            a[t]=a[0]-a[t];
            a[0]=a[0]-a[t];
        }
        for (i=0; i<n; i++)
        printf("%d ",a[i]);
        printf("\n");
        scanf("%d",&n);
    }
return 0;
}
        