 
#include <stdio.h>

int main()
{
    int n;
    while (scanf("%d",&n)&&n!=0) {
        int a[n],t=0,j;
        for (int i=0; i<n; i++) {
            scanf("%d",&a[i]);
            if (a[t]>a[i]) {
                t=i;
            }
        }j=a[0];
        a[0]=a[t];
        a[t]=j;
        for (int i=0; i<n; i++) {
            printf("%d ",a[i]);
        }printf("\n");
    }
}        