 
//
//  main.cpp
//  小珂的苦恼
//
//  Created by Mori.William on 14-9-21.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>

int gcd(int a,int b)
{
    int temp;
    while (b!=0) {
        temp = b;
        b = a%b;
        a = temp;
    }
    return a;
}

int main()
{
    int a,b,c,loop;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d%d%d",&a,&b,&c);
        if (c%gcd(a, b)==0)
            printf("Yes\n");
        else
            printf("No\n");
    }
}        