 
#include <stdio.h>
int main()
{
    int a, b, i;
    while(scanf("%d%d", &a, &b) != EOF){
        if (a == 0 && b == 0) break;
        for (i = 0 ; i < 100; i++){
            if ((a * 100 + i) % b == 0)
                printf(" %02d", i);
        }
        printf("\n");
    }
    return 0;
}        