 
#include <cstdio>
#include <cstdlib>
#include <cstring>

int main()
{

    int m,n,sum = 0;
    char str[7];
    scanf("%d%d",&n,&m);
    bool *a = (bool *) malloc (sizeof (bool) *n);
    for(int i = 0;i!=n;i++)
        a[i] = false;
    while(m--){
        scanf("%s",str);
        if(str[0]=='C'){
            scanf("%d",&n);
            n--;
            if(a[n]){
                sum--;
                a[n] = false;
            }
            else{
                sum++;
                a[n] = true;
            }
        }else
            printf("%d\n",sum);
    }
}
        