 
#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    int n,m,t,sum=0;
    scanf("%d%d",&n,&m);
    bool *a = new bool[n];
    char b[10];
    while (m--) {
        scanf("%s",b);
        if (b[0]=='C') {
            scanf("%d",&t);
            if (a[t]) {
                a[t] = false;
                sum--;
            } else {
                sum++;
                a[t] = true;
            }
        } else
            printf("%d\n",sum);
    }
}        