 
//
//  main.c
//  小木块
//
//  Created by Moridisa on 14-4-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int sumI=0,sum=0,n,d=0;
        scanf("%d",&n);
        for (int i=1; i<=n; i++) {
            d+=i;
        }for (int i=1; i<=n; i++) {
            sumI=0;
            for (int j=1; j<=i; j++) {
                sumI+=j;
            }sum+=sumI;
        }printf("%d\n",sum);
    }
}        