 
#include <stdio.h>
#include <string.h>

int Juge(char s[],int len)
{
	int i,j,k=len/2;
	if(len==2){
		if(s[0]==s[1])
			return 1;
		return 2;
	}
	for(i=0;i<k;i++){
		j=len-i-1;
		if(s[i]!=s[j])
			return len;
		if(i==j-1&& k%2!=0)
			return k;
	}
	Juge(s,k);
}

int main()
{
	int loop;
	scanf("%d",&loop);
	while(loop--){
		char s[101];
		scanf("%s",s);
		printf("%d\n",strlen(s)%2==0?Juge(s,strlen(s)):strlen(s));
	}
}

        