 
#include <iostream>
#include <algorithm>
#include <bitset>
#include <cstdio>
using namespace std;

bitset<100000002> a;
int main()
{
    int loop,n,m;
    string c;
    cin>>loop;
    while (loop--) {
        cin>>c>>n;
        if (c=="ADD") {
            for (int i = 0; i<n; i++) {
                scanf("%d",&m);
                a[m] = 1;
            }
        } else {
            for (int i = 0; i<n; i++) {
                scanf("%d",&m);
                if (a[m])
                    printf("YES\n");
                else
                    printf("NO\n");
            }
        }
    }
    return 0;
}        