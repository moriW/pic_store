 
//
//  main.cpp
//  奇怪的排序
//
//  Created by Moridisa on 14-6-30.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cstdlib>
using namespace std;

int daozhi(int a)
{
    int sum=0;
    while (a) {
        sum+=sum*10+a%10;
        a/=10;
    }
    return sum;
}

bool cmp(int x,int y)
{
    return daozhi(y)>daozhi(x);
}

int main()
{
    int loop,begin,end,n;
    cin>>loop;
    while (loop--) {
        
        cin>>begin>>end;
        n=end-begin+1;
        int a[50]={0};
        
        for (int i=0; i<n;  begin++, i++)
            a[i]=begin;
        
        sort(a, a+n,cmp);
        int i;
        for (i=0; i<n; i++)
            cout<<a[i]<<' ';
        cout<<endl;
    }
    return 0;
}        