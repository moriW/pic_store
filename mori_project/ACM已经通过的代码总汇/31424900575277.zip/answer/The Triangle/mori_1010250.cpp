 
//
//  main.cpp
//  The Triangle
//
//  Created by Mori.William on 14/10/18.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;


int main()
{
    int dp[105][105],n;
    while (cin>>n) {
        memset(dp, 0, sizeof(dp));
        for (int i = 0; i != n; i++)
            for (int j = 0; j<=i; j++)
                cin>>dp[i][j];
        
        for (int i = n - 1; i >= 0; i--) {
            for (int j = i; j >= 0 ; j--) {
                dp[i][j] = max(dp[i][j] + dp[i+1][j], dp[i][j] + dp[i+1][j+1]);
            }
        }
        cout<<dp[0][0]<<endl;
    }
}        