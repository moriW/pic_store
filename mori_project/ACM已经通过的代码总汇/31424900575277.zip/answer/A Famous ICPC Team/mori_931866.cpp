 
#include <stdio.h>
#include <algorithm>
using namespace std;
#define max(a,b) a>b?a:b
int main()
{
    int n = 0,a[4];
    while (scanf("%d%d%d%d",&a[0],&a[1],&a[2],&a[3])!=EOF) {
        n++;
        sort(a, a+4);
        printf("Case %d: %d\n",n,a[2]+a[3]);
    }
}        