 
//
//  main.c
//  背包问题
//
//  Created by Moridisa on 14-4-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <stdio.h>

void    maoP(int a[],int b[],int n)
{
    int t;
    for (int i=0; i<n; i++) {
        for (int j=i+1; j<n; j++) {
            if (a[i]>a[j]) {
                t=a[i];
                a[i]=a[j];
                a[j]=t;
                t=b[i];
                b[i]=b[j];
                b[j]=t;
            }
        }
    }
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n,bbZz,value=0;
        scanf("%d%d",&n,&bbZz);
        int v[n],w[n],t=n-1;
        for (int i=0; i<n; i++) {
            scanf("%d%d",&v[i],&w[i]);
        }maoP(v,w,n);
        while (bbZz) {
            if (bbZz>=w[t]) {
                value+=w[t]*v[t];
                bbZz-=w[t];
                t--;
                continue;
            }if (w[t]>bbZz) {
                value+=bbZz*v[t];
                break;
            }
        }printf("%d\n",value);
    }
}        