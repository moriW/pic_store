 
//
//  main.c
//  谁拿了最高奖学金
//
//  Created by Moridisa on 14-3-19.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int loop,fs[2],wz,pe;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&pe);
        char    name[21],bigger[21],sf[4];
        int all=0,k=0,maxMoney=0;
        for(int i=0;i<pe;i++){
            int money=0;
            scanf("%s%d%d%c%c%c%c%d",name,&fs[0],&fs[1],&sf[0],&sf[1],&sf[2],&sf[3],&wz);
            if (fs[0]>80&&wz>=1) {
                money+=8000;
            }if (fs[0]>85&&fs[1]>80) {
                money+=4000;
            }if (fs[0]>90) {
                money+=2000;
            }if (fs[0]>85&&sf[3]=='Y') {
                money+=1000;
            }if (fs[1]>80&&sf[1]=='Y') {
                money+=850;
            }all+=money;
            if (money>k&&money>maxMoney) {
                for (int i=0; i<21; i++) {
                    bigger[i]=name[i];
                }
                maxMoney=money;
            }
            k=money;
        }printf("%s\n%d\n%d\n",bigger,maxMoney,all);
    }
}        