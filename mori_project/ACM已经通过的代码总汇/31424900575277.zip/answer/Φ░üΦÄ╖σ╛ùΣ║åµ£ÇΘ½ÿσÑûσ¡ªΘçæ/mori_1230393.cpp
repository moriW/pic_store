 
//
//  main.cpp
//  最高奖学金
//
//  Created by Mori.William on 15/4/13.
//  Copyright (c) 2015年 Mori.William. All rights reserved.
//

#include <iostream>
#include <cstring>
using namespace std;

struct student{
    char name[25];
    int socreTest;
    int socreClass;
    char member;
    char xibu;
    int article;
    int money;
};

int main()
{
    int loop,n,money,sum;
    student stu[102];
    char name[20];
    cin>>loop;
    while (loop--) {
        cin>>n;
        money = 0;
        sum = 0;
        for (int i = 0; i != n; i++) {
            cin>>stu[i].name>>stu[i].socreTest>>stu[i].socreClass>>stu[i].member>>stu[i].xibu>>stu[i].article;
            //cout<<stu[i].name<<' '<<stu[i].socreTest<<' '<<stu[i].socreClass<<' '<<stu[i].member<<' '<<stu[i].xibu<<' '<<stu[i].article<<endl;
            stu[i].money = 0;
            
            if (stu[i].socreTest > 80 && stu[i].article >= 1)
                stu[i].money += 8000;
            
            if (stu[i].socreTest > 85 && stu[i].socreClass > 80)
                stu[i].money += 4000;
            
            if (stu[i].socreTest > 90)
                stu[i].money += 2000;
            
            if (stu[i].socreTest > 85 && stu[i].xibu == 'Y')
                stu[i].money += 1000;
            
            if (stu[i].socreClass > 80 && stu[i].member == 'Y')
                stu[i].money += 850;
        
            if (stu[i].money > money) {
                money = stu[i].money;
                strcpy(name, stu[i].name);
            }
            sum += stu[i].money;
        }
        
        cout<<name<<endl<<money<<endl<<sum<<endl;
        
    }
}        