 
//
//  main.c
//  对称排序
//
//  Created by Moridisa on 14-4-12.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <stdio.h>
#include <string.h>
void maoP(char s[][26],int n)
{
    char f[26];
    int i,j;
    for (i=0; i<n; i++){
        for (j=0; j<n-i-1; j++){
            if (strlen(s[j])>strlen(s[j+1])){
                strcpy(f, s[j]);
                strcpy(s[j], s[j+1]);
                strcpy(s[j+1], f);
            }
        }
    }
}
int main()
{
    int n,t=0;
    while (scanf("%d",&n)&&n!=0)
    {
        t++;
        char s[16][26];
        for (int i=0; i<n; i++)
        {
            scanf("%s",s[i]);
        }printf("SET %d\n",t);
        maoP(s, n);
        for (int i=0; i<n; i++) {
            if (i%2==0) {
                printf("%s\n",s[i]);
            }
        }for (int j=n-1; j>0; j--) {
            if (j%2!=0) {
                printf("%s\n",s[j]);
            }
        }
    }
}
        