 
//
//  main.cpp
//  最少乘法次数
//
//  Created by mori on 14-9-12.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <cstdio>

int main()
{
    int a[17]={1};
    for (int i = 1; i!=17; i++)
        a[i] = a[i-1] * 2;
    int loop,n,t,k;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&n);
        t = 0;
        while (n>0) {
            k = 16;
            while (n<a[k])
                k--;
            //printf("%d ",a[k]);
            n -= a[k];
            if (t==0)
                t += k;
            else
                t++;
        }
        printf("%d\n",t);
    }
}        