 
// 无主之地.cpp : 定义控制台应用程序的入口点。
//

#include <stdio.h>

int main()
{
	int a,b,local[20]={0},num[20]={0},time;
	while(scanf("%d%d",&a,&b)!=0&&(a!=0&&b!=0)){
		for(int i=0;i<20;i++){
			if(local[i]==a){
				num[i]+=b;
				break;
			}
			if(local[i]==0){
				local[i]=a;
				num[i]+=b;
				break;
			}
		}
	}for(int i=0;i<20;i++){
		if(local[i]!=0)
			printf("%d %d\n",local[i],num[i]);
	}
}        