 
//
//  main.cpp
//  intersection set
//
//  Created by Moridisa on 14-6-10.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    int n,m;
    int *a=(int *)malloc(sizeof(int)*100002);
    while (scanf("%d%d",&n,&m)!=EOF) {
        int b,max=0,t=0;
        //memset(a, 0, sizeof(a));
        for (int i=0; i<100002; i++)
            a[i]=0;
        for (int i=0; i<n+m; i++) {
            scanf("%d",&b);
            a[b]++;
            if (b>max)
                max=b;
        }
        for (int i=0; i<=max; i++){
            t += a[i]==2? 1:0;
            //printf("%d:%d\n",i,a[i]);
        }
        printf("%d\n",t);
    }
}        