 
// 兰州烧饼.cpp : 定义控制台应用程序的入口点。
//

#include "stdio.h"


int main()
{
	int n,k,t;
	while(scanf("%d%d",&n,&k)!=EOF){
		if(n<=k/2)
			printf("2\n");
		else{
			n*=2;
			printf("%d\n",n%k==0?n/k:n/k+1);
		}
	}
}        