 
#include <stdio.h>

int main()
{
    int i,n;
    scanf("%d",&i);
    if (i>=2&&i<30) {
        while(i!=0){
            i--;
            scanf("%d",&n);
        if (n>=2&&n<=10000) {
            int jishu=1,oushu=2;
            while (jishu-1!=n) {
                printf("%d ",jishu);
                jishu+=2;
            }
            printf("\n");
            while (oushu<n+1) {
                printf("%d ",oushu);
                oushu+=2;
            }
            printf("\n");
        }
        }
    }
    return 0;
}        