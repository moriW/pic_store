 
#include <stdio.h>
int main()
{
    int a,b,sum;
    while (scanf("%d%d",&a,&b)!=EOF) {
        sum = 0;
        if (b>=5) {
            b-=5;
            sum += 10;
            sum += (b/4)*9;
            sum += (b%4);
        }
        else
            sum+=b;
        printf("%d\n",sum+a);
    }
}        