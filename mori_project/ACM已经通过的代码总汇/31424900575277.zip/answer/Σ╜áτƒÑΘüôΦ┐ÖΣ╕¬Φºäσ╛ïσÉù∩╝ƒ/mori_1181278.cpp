 
#include <stdio.h>

int main()
{
    
    char get[10002];
    int result,b;
    b = 0;
    
    while (~scanf("%s %d",get,&b)) {
        result = 0;
        
        for (int i = 0; get[i] != '\0'; i++) {
            result = result * 10 + get[i] - 48;
            result %= b;
        }
        printf("%d\n",result);
    }
    
    return 0;
}        