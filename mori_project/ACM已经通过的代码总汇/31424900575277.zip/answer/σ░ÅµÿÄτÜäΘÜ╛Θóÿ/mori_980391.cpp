 
//
//  main.cpp
//  小明的难题
//
//  Created by Mori.William on 14-9-23.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>
#include <cstring>

int main()
{
    int loop,temp = 'a'-'A';
    char str[100];
    scanf("%d",&loop);
    while (loop--) {
        scanf("%s",str);
        for (int i = 0; i < strlen(str); i += 2) {
            if ( str[i]>='a' && str[i]<='z')
                str[i] -= temp;
        }
        printf("%s\n",str);
    }
}        