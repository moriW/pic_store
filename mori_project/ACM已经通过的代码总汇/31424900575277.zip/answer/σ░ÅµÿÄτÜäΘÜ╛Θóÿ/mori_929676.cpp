 
#include<iostream>
using namespace std;
int main() {
    int loop, n;
    cin >> loop;
    while (loop--) {
        long long a = 1, b = 1, c = 1;
        cin >> n;
        for(int i = 2; i <= n; i++) {
            b *= i;
            c += b * a;
            a *= -1;
        }
        cout << c << endl;
    }
}
        