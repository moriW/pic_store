 
//
//  main.cpp
//  兔子的烦恼(一)
//
//  Created by mori on 14-9-13.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
using namespace std;

int gcd(int a,int b)
{
    return b==0 ? a:gcd(b, a%b);
}

int main()
{
    int a,b;
    while (cin>>a>>b) {
        if (gcd(a, b)==1)
            cout<<"NO"<<endl;
        else
            cout<<"YES"<<endl;
    }
}        