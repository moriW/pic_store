 
#include <iostream>
using namespace std;

int main()
{
    int a[5];
    while (cin>>a[0]>>a[1]>>a[2]>>a[3]>>a[4]) {
        for (int i=0; i<5; i++)
            a[i]=a[i]*10+5;
        int sum=0,b;
        for (int i=0; i<5; i++){
            cin>>b;
            sum+=b-a[i];
        }
        if (sum>0)
            cout<<"Yes "<<sum<<endl;
        else
            cout<<"No !"<<endl;
    }
}        