 
#include <cstdio>
#include <cstdlib>

int main(){
int n, t;
while(scanf("%d", &n) == 1)	
printf("%d\n", (abs(n - 1) + 1) * (1 + n) / 2);	
return 0;
}        