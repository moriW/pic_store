 
//
//  main.cpp
//  阶乘因式分解(二)
//
//  Created by Mori.William on 14-9-15.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int loop;
    cin>>loop;
    long long n,m,sum;
    while (loop--) {
        cin>>n>>m;
        sum = 0;
        while (n!=0) {
            sum += n/m;
            n /= m;
        }
        cout<<sum<<endl;
    }
}        