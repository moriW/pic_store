 
#include <iostream>
using namespace std;

int main()
{
    int n;
    while (cin>>n,n!=0) {
        int sum=0,a;
        for (int i=0; i<n; i++) {
            cin>>a;
            sum+=a*a;
        }
        cout<<sum<<endl;
    }
}        