 
#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int main()
{
    int loop,n,sum;
    cin>>loop;
    while (loop--) {
        cin>>n;
        int *a = new int[n];
        for (int i = 0; i<n; i++)
            scanf("%d",&a[i]);
        sort(a, a+n);
        sum = a[n-1]-a[0];
        printf("%d\n",sum);
        delete [] a;
    }
}        