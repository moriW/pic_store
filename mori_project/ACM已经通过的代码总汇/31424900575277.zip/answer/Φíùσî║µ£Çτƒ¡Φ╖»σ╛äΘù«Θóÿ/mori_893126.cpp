 
//
//  main.cpp
//  街区最短路径
//
//  Created by Moridisa on 14-6-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <math.h>
using namespace std;

int main()
{
    int loop;
    cin>>loop;
    while (loop--) {
        //cout<<loop<<endl;
        int n,sum=0,x1,y1;
        cin>>n;
        int *x=(int *)malloc(sizeof(int)*n);
        int *y=(int *)malloc(sizeof(int)*n);
        for (int i=0; i<n; i++){
            cin>>x[i]>>y[i];
            //cout<<x[i]<<' '<<y[i]<<endl;
        }
        sort(x, x+n);
        sort(y, y+n);
        x1=x[n/2];
        y1=y[n/2];
        for (int i=0; i<n; i++)
            sum+=abs(x[i]-x1)+abs(y[i]-y1);
        cout<<sum<<endl;
        free(x);
        free(y);
    }
}        