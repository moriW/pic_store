 
//
//  main.cpp
//  欧几里得
//
//  Created by Moridisa on 14-5-28.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <memory.h>
using namespace std;

int main()
{
    int loop;
    cin>>loop;
    while (loop--) {
        int n;
        cin>>n;
        int *a=(int *)malloc(sizeof(int)*n);
        for (int i=0; i<n; i++)
            cin>>a[i];
        sort(a, a+n);
        cout<<a[(n-1)/2]<<endl;
    }
}        