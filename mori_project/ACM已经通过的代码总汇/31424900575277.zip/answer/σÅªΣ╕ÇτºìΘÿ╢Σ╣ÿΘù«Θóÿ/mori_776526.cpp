 
//
//  main.c
//  另一种阶乘问题
//
//  Created by Moridisa on 14-3-21.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int jc(int n)
{
    int shu=1;
    for (int i=1;i<=n;i++){
        if (i%2!=0) {
            shu=shu*i;
        }
    }return shu;
}

int main()
{
    int loop,n,sum=0;
    scanf("%d",&loop);
    while (loop--) {
        sum=0;
        scanf("%d",&n);
        for (int i=1; i<=n; i++) {
            sum+=jc(i);
        }
        printf("%d\n",sum);
    }
}        