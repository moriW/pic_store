 
//
//  main.c
//  房间安排
//
//  Created by Moridisa on 14-4-8.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <stdio.h>

int MaxN(int a[])
{
    int c=0;
    for (int i=0; i<181; i++) {
        if (a[i]>c) {
            c=a[i];
        }
    }return c;
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n,a[200000]={0},rom,day,fordy;
        scanf("%d",&n);
        for (int i=0; i<n; i++) {
            scanf("%d%d%d",&rom,&day,&fordy);
            for (int j=day-1; j<day+fordy-1; j++) {
                a[j]+=rom;
            }
        }printf("%d\n",MaxN(a));
    }
}        