 
//
//  main.c
//  cigarettes
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
int main()
{
    int loop,n,k,x;
    scanf("%d",&loop);
    while (loop--) {
        int z=0;
        scanf("%d%d",&n,&k);
        x=n;
        while (n/k) {
            z+=n/k;
            n=n/k+n%k;
        }
        printf("%d\n",x+z);
    }
}        