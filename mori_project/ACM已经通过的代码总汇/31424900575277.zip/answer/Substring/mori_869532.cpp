 
#include <iostream>
#include <string.h>
#include <memory.h>

using namespace std;

void fanZ(char a[],char b[],int le,int ri)
{
    int i;
    for(i=0;ri>=le;ri--,i++)
        b[i]=a[ri];
    b[i]='\0';
}

int main()
{
    int loop;
    cin>>loop;
    while(loop--){

        char a[52],b[52],c[52];

        memset(a,0,sizeof(a));
        memset(b,0,sizeof(b));

        cin>>a;

        int len=(int)strlen(a);
        int left=0,rig=len-1;

        fanZ(a,b,0,rig);
        //cout<<b<<endl;
        if(strcmp(a,b)==0){
            cout<<a;
            goto mark;
        }
        memset(b,0,sizeof(b));

        for(int i=1;i<=len-1;i++){

            left=0;
            int ri=rig-i;

            for(int j=0;j<=i;j++){
                fanZ(a,b,left,ri);
                if(strstr(a,b)!=NULL){
                    int lenb=strlen(b);
                    for(int k=lenb-1;k>=0;k--)
                        cout<<b[k];
                    goto mark;
                }
                left++,ri++;
                memset(b,0,sizeof(b));
            }
        }

        mark: cout<<endl;continue;

    }

    return 0;
}
        