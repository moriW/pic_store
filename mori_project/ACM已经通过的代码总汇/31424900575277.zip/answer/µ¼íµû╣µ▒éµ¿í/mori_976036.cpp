 
//
//  main.cpp
//  次方求模
//
//  Created by Mori.William on 14-9-17.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    int loop;
    bool step[200000];
    long long a,b,c,d;
    cin>>loop;
    while (loop--) {
        cin>>a>>b>>c;
        a %= c;
        d = a;
        int i = 0;
        memset(step, false, sizeof(step));
        while (b>1) {
            if (b%2==1 || b==2)
                b--;
            else{
                b /= 2;
                step[i] = true;
            }
            i++;
        }
        i--;
        while (i >= 0) {
            if (step[i]){
                a %= c;
                a *= a;
            }
            else{
                a %= c;
                a *= d;
            }
            a %= c;
            i--;
        }
        cout<<a<<endl;
    }
}        