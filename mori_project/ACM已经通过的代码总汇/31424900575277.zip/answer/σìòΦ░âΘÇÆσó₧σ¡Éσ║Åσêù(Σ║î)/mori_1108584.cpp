 
//
//  main.cpp
//  单调递增子序列(二)
//
//  Created by Mori.William on 14/12/5.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//


#include <iostream>
#include <algorithm>
#include <queue>
#include <list>
#include <stack>
#include <cstdio>
#include <cstring>

using namespace std;

int dp[100005];
int ap[100005];

int binarySreach(int p,int right)
{
    int left = 1;
    int mid = (left + right) >> 1;
    while (left <= right) {
        if (dp[mid] == p)
            return mid;
        else if ( dp[mid] > p )
            right = mid - 1;
        else
            left = mid + 1;
        mid = (left + right ) >> 1;
    }
    return left;
}

int main()
{
    int n;
    int t,length;
    while (~scanf("%d",&n)) {
        length = 1;
        t = 0;
        memset(dp, 0, sizeof(dp));
        memset(ap, 0, sizeof(ap));
        for (int i = 0 ; i != n; i++)
            scanf("%d",&ap[i]);
        dp[1] = ap[0];
        for (int i = 1; i != n; i++) {
            t = binarySreach(ap[i], length);
            dp[t] = ap[i];
            length = length > t ? length : t;
        }
        printf("%d\n",length);
    }
    return 0;
}        