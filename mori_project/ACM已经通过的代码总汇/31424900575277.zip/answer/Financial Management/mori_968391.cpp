 
#include <stdio.h>

int main()
{
      float b=0,sum=0;
      for(int i = 0;i!=12;i++){
             scanf("%f",&b);
             sum+=b;
      }
      printf("%.2f\n",sum/12);
}
        