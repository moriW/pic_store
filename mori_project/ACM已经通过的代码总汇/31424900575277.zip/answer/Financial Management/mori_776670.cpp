 
//
//  main.c
//  Financial Management
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    float a[12],sum=0;
    for (int i=0; i<12; i++) {
        scanf("%f",&a[i]);
        sum+=a[i];
    }printf("%.2f",sum/12);
}
        