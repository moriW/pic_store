 
//
//  main.cpp
//  不吉利的数字
//
//  Created by Mori.William on 14-9-20.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include<fstream>
#include <cstdio>
using namespace std;

bool juge(int n)
{
    while (n) {
        if (n%10==0)
            return false;
        n/=10;
    }
    return true;
}

int main()
{
    int a[1000003],temp;
    for (int i = 0,j = 0; i!=1000003;j++,i++) {
        if (juge(i))
            a[i] = j;
        else{
            a[i] = 0;
            j--;
        }
    }
    
    while (cin>>temp) {
        if(a[temp])
            cout<<a[temp]<<endl;
        else
            cout<<"Unlucky"<<endl;
    }
    
}        