 
#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <cstdio>
//from coder mori
using namespace std;

int main()
{
    int n;
    char b[100];
    //freopen("c.txt","r",stdin);
    cin>>n;
    getchar();
    for(int i=0;i<n;i++){
        gets(b);
        cout<<b[0];
    }cout<<endl;
}
        