 
#include <stdio.h>

int main()
{
    int sum=0,loop,loop_,num;
    int juge;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&loop_);
        for(int k=0;k<loop_;k++) {
            scanf("%d",&num);
            if(num==1){
                num=0;
            }else if (num==2){
                juge=1;
                num=2;
            }
            else{
                for (int i=2; i<num; i++) {
                    if (num%i!=0) {
                            juge=1;
                    }if (num%i==0){
                        juge=0;
                        break;
                    }
                }
            }
            if (juge==1) {
                sum+=num;
            }
        }
        printf("%d\n",sum);
        sum=0;
    }
}
        