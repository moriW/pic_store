 
//
//  main.cpp
//  我要我就要
//
//  Created by Mori.William on 15/4/13.
//  Copyright (c) 2015年 Mori.William. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int n,temp,count;
    while (cin>>n) {

        temp = 1;
        count = 1;
        
        while (temp % n != 0) {
            temp = temp % n;
            temp *= 10;
            temp++;
            count++;
        }
        
        cout<<count<<endl;
        
    }
}        