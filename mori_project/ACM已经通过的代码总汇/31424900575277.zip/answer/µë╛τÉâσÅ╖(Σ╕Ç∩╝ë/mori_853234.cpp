 
//
//  main.cpp
//  找球号
//
//  Created by Moridisa on 14-5-2.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <algorithm>
#define mid(a,b) (a+b)/2
using namespace std;

int a[1000000],b;

int main()
{
    int x,y;
    scanf("%d%d",&x,&y);
    for (int i=0; i<x; i++)
        scanf("%d",&a[i]);
    sort(a, a+x);
    for (int i=0; i<y; i++) {
        scanf("%d",&b);
        int left=0,right=x-1;
        while (right-left>1) {
            if (a[mid(left, right)]>b)
                right = mid(left, right);
            else
                left = mid(left,right);
        }
        if(a[mid(left, right)]==b)
            printf("YES\n");
        else
            printf("NO\n");

    }
}        