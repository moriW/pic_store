 
//
//  main.cpp
//  小珂的图表
//
//  Created by mori on 14-9-13.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <cstring>
using namespace std;
bool a[101][101]={false};
void tuSe(bool color,int x,int y,int xx,int yy)
{
    for (int i = x; i<=xx; i++)
        for (int j = y; j<=yy; j++)
            a[i][j] = color;
}
int main()
{
    int n,x,y,xx,yy,l,sum = 0;
    cin>>n;
    while (n--) {
        a;
        sum = 0;
        char str[10];
        cin>>str>>x>>y>>l;
        //判断是否超出101
        x = (x>100) ? 100:x;
        y = (y>100) ? 100:y;

        xx = (x+l-1)>100 ? 100:x+l-1;
        yy = (y+l-1)>100 ? 100:y+l-1;
        
        if (str[0]=='B')
            tuSe(true, x, y, xx, yy);
        else if(str[0]=='W')
            tuSe(false, x, y, xx, yy);
        else{
            for (int i = x; i<=xx; i++)
                for (int j = y; j<=yy; j++ )
                    if (a[i][j])
                        sum++;
            cout<<sum<<endl;
        }
    }
    
}        