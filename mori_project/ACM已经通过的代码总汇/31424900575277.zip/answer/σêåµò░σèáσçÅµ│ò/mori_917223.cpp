 
#include<stdio.h>
#include<math.h>

int abs(int a)
{
    if (a>0)
        return a;
    return (-1*a);
}

int main()
{
    int gcd(int x,int y);
    int a,b,c,d,m,n,t;
    char o;
    //printf("%d",abs(-3));
    while(scanf("%d/%d%c%d/%d",&a,&b,&o,&c,&d)!=EOF)
    {
        if(o=='+')
        {
            if(b==d)
            {
                m=a+c;
                n=b;
            }
            else
            {
                m=a*d+b*c;
                n=b*d;
            }
        }
        if(o=='-')
        {
            if(b==d)
            {
                if(a==c){
                    printf("0\n");
                    continue;
                }
                else
                {
                    m=a-c;
                    n=b ;
                }
            }
            else
            {
                m=a*d-b*c;
                n=b*d;
            }
        }
        //printf("%d %d\n",m,n);
        if (m==n)
            printf("1\n");
        else{
            t = abs(gcd(m, n));
            n/=t;
            m/=t;
            if (n==1)
                printf("%d\n",m);
            else
                printf("%d/%d\n",m,n);
        }
    }
    return 0;
}
int gcd(int x,int y)
{
    return y == 0?x: gcd(y,x%y);
}        