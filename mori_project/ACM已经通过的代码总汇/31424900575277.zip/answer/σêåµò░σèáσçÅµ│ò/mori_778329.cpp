 
//
//  main.c
//  分数加减法
//
//  Created by Moridisa on 14-3-23.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
int tongfen(int fenmu1,int fenmu2)
{
    int t=fenmu1*fenmu2,n=1;
    while (fenmu2!=0) {
        n=fenmu1%fenmu2;
        fenmu1=fenmu2;
        fenmu2=n;
    }return t/fenmu1;
}
void yufen(int fenzi,int fenmu)
{
    for (int i=2; i<fenmu; i++) {
        if (fenmu%i==0&&fenzi%i==0) {
            fenmu=fenmu/i;
            fenzi=fenzi/i;
        }if (fenzi==0) {
            printf("0\n");
            break;
        }
        else if (fenmu%fenzi==0) {
            fenmu=fenmu/fenzi;
            fenzi=1;
            if (fenmu<0) {
                fenmu*=-1;
                fenzi*=-1;
            }
        }
    }
    if(fenzi%fenmu==0){
        printf("%d\n",fenzi/fenmu);
    }else{
        printf("%d/%d\n",fenzi,fenmu);
    }
}
int main()
{
    int a,b,c,d,fenmu,fenzi;
    char chu1,chu2,jiajian;
    while (scanf("%d%c%d%c%d%c%d",&a,&chu1,&b,&jiajian,&c,&chu2,&d)!=EOF) {
        if (b==d) {
            fenmu=b;
            if (jiajian=='+') {
                fenzi=a+c;
            }else{
                
                fenzi=a-c;
            }
                yufen(fenzi, fenmu);
        }if(b!=d){
            fenmu=tongfen(b, d);
            if (jiajian=='+') {
                fenzi=a*(fenmu/b)+c*(fenmu/d);
            }else{
                fenzi=a*(fenmu/b)-c*(fenmu/d);
            }
            yufen(fenzi, fenmu);
        }
    }
}        