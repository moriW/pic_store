 
#include <stdio.h>
#include <string.h>

int Prii(char a[],int l,int r)
{
    int b=0,j=0;
    for (int i=r; i>=l; i--) {
        if (a[i]-'0'>=b){
            b=a[i]-'0';
            j=i;
        }
    }printf("%d",b);
    return j+1;
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        char a[101];
        int c,d,l,r;
        scanf("%s%d",a,&c);
        d=(int)strlen(a)-c;
        l=0;r=c;
        while (d--) {
            l=Prii(a, l, r);
            r++;
        }printf("\n");
    }
}        