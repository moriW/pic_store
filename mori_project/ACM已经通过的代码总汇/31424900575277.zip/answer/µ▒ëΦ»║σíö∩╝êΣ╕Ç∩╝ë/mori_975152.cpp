 
//
//  main.cpp
//  汉诺塔(一)
//
//  Created by mori on 14-9-12.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
using namespace std;

void poww(long long *sum,bool a[],int t)
{
    if (t==-1)
        return ;
    else{
        if (a[t]) {
            *sum *= *sum;
            *sum %= 1000000;
        } else {
            *sum *= 2;
            *sum %= 1000000;
        }
        t--;
        poww(sum, a, t);
    }
}

void setO(bool a[])
{
    for (int i = 0; i!=200001; i++)
        a[i] = false;
}

int main()
{
    bool k[200001];
    int loop,n,p;
    long long sum = 2;
    cin>>loop;
    while (loop--) {
        //初始化值
        p = 0;
        sum = 2;
        setO(k);
        cin>>n;
        while (n > 1) {
            if (n%2 || n==2) {
                n--;
                k[p] = false;
            } else {
                n /= 2;
                k[p] = true;
            }
            p++;
        }
        p--;
        poww(&sum, k, p);
        cout<<sum-1<<endl;
    }
}        