 
//
//  main.cpp
//  一种排序
//
//  Created by Moridisa on 14-5-28.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <string.h>
#include <memory.h>
using namespace std;

struct cfx
{
    int bianhao;
    int chang;
    int kuan;
}a[100002];


bool cmp(struct cfx x,struct cfx y)
{
    if (x.bianhao>y.bianhao)return false;
    if (x.bianhao==y.bianhao&&x.chang>y.chang)return false;
    if (x.bianhao==y.bianhao&&x.chang==y.chang&&x.kuan>y.kuan)return false;
    return true;
}

int main()
{
    int loop,n,t;
    cin>>loop;
    while (loop--) {
        cin>>n;
        memset(a, 0, sizeof(a));
        for (int i=0; i<n; i++){
            cin>>a[i].bianhao>>a[i].chang>>a[i].kuan;
            if (a[i].kuan>a[i].chang) {
                t=a[i].chang;
                a[i].chang=a[i].kuan;
                a[i].kuan=t;
            }
        }
        sort(a, a+n, cmp);
        for (int i=0; i<n; i++) {
            if (a[i].bianhao!=a[i+1].bianhao||a[i].chang!=a[i+1].chang||a[i].kuan!=a[i+1].kuan)
                cout<<a[i].bianhao<<' '<<a[i].chang<<' '<<a[i].kuan<<endl;
        }
    }
}        