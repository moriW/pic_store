 
#include <stdio.h>

int a[2000000]={1,1};

int main()
{
    int i,j=0,k,n;
    //da biao 0 da biao sushu    1 da biao feisushu 
    for(i=2;i<2000001;i++){
        if(a[i]==0){
            for(j=i+i;j<2000001;j+=i)
                a[j]=1;
        }
    }
    
    while(scanf("%d",&n) && n){
        for(k=2;k<=n;k++){
            if(a[k]==0)
                //break;
                printf("%d ",k);
        }
        printf("\n");
    }
}
        