 
#include <iostream>
using namespace std;
int main() {
cout << 1 <<" "<<2 <<" "<< 11 <<" " <<101 <<" " << 111 << endl;
cout << 1001 <<" "<< 10001 <<" "<< 10101 <<" " <<11011 <<" " << 100001 << endl;
cout << 101101 <<" "<< 110011 << endl;
}        