 


//
//  main.cpp
//
//
//  Created by Moridisa on 14-3-17.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <algorithm>
#include <cstdio>
using namespace std;

bool cmp(int a,int b){return a>b;}

int main()
{
    int n;
    while (scanf("%d",&n)!=EOF) {
        int *tian = new int[n];
        int *king = new int[n];
        int sum = 0,pj = 0;
        for (int i = 0; i<n; i++)
            scanf("%d",&tian[i]);
        for (int i = 0; i<n; i++)
            scanf("%d",&king[i]);
        sort(tian, tian+n);
        sort(king, king+n);
        for (int i = 0; i<n; i++) {
            for (int j = n-1; j!=-1; j--) {
                if (tian[i]>king[j]&&tian[i]!=0&&king[j]!=0) {
                    sum++;
                    king[j] = 0;
                    tian[i] = 0;
                    break;
                }
            }
        }
        
        for (int i = 0; i<n; i++) {
            for (int j = n-1; j!=-1; j--) {
                if (tian[i]!=0&&king[j]!=0&&tian[i]==king[j]) {
                    pj++;
                    tian[i] = 0;
                    king[j] = 0;
                    break;
                }
            }
        }
        pj=n-sum-pj;
        sum-=pj;
        printf("%d\n",sum*200);
        delete [] king;
        delete [] tian;
    }
    return 0;
}        