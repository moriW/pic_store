 
#include<cstdio>
#include<algorithm>
using namespace std;
bool cmp(int a,int b)
{
return a>b;
}
int main()
{
int n,i,tian[1005],guo[1005],sum,he,qian,j;
while((scanf("%d",&n))!=EOF)
{
sum=0;he=0;
for(i=0;i<n;i++)
{
scanf("%d",&tian[i]);
}
for(i=0;i<n;i++)
{
scanf("%d",&guo[i]);
}
sort(tian,tian+n);
sort(guo,guo+n,cmp);
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
if(tian[i]>guo[j]&&guo[j]!=0&&tian[i]!=0)
{
sum++;
guo[j]=0;tian[i]=0;
break;
}
}
}
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
if(tian[i]!=0&&guo[j]!=0&&tian[i]==guo[j])
{
he++;
tian[i]=0;guo[j]=0;break;
}
}
}
he=n-he-sum;
sum-=he;
printf("%d\n",sum*200);
}
return 0;
}
        