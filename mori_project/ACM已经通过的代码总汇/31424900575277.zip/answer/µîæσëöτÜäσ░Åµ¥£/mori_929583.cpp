 
#include <string.h>
#include <stdio.h>
#include <algorithm>
using namespace std;
int main()
{
    int loop;
    char a[1002];
    scanf("%d",&loop);
    while (loop--) {
        int num[1002],k=0,j=0;
        char zimu[1002];
        scanf("%s",a);
        for (int i = 0; a[i]!='\0' ; i++) {
            if (a[i]>='0'&&a[i]<='9') {
                num[k] = a[i]-'0';
                k++;
            }
            else if ((a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')){
                zimu[j] = a[i];
                j++;
            }
        }
        sort(num, num+k);
        zimu[j] = '\0';
        printf("%d ",(int)strlen(zimu));
        for (j--; j!=-1; j--)
            printf("%c",zimu[j]);
        printf("\n");
        printf("%d ",k);
        if (k!=0) {
            for (int i=k-1; i!=-1; i--)
                printf("%d",num[i]);
        }
        printf("\n");
    }
}        