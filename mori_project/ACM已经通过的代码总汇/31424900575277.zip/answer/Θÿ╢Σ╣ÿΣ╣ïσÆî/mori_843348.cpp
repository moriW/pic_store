 
//
//  main.c
//  阶乘之和
//
//  Created by Moridisa on 14-4-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int loop,n,i,a[11]={1};
    for (i=1; i<9; i++){
        a[i]=a[i-1]*(i+1);
        //printf("%d ",a[i]);
    }
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&n);
        for(i=8;i>=0;i--){
            if(n>=a[i])
                n-=a[i];
        }
        if(n==0)
            printf("Yes\n");
        else
            printf("No\n");
    }
    return 0;
}        