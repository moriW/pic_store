 
#include <stdio.h>
int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        char a,b,c;
        getchar();
        scanf("%c%c%c",&a,&b,&c);
        if (a==c) {
            printf("%c=%c\n",a,c);
        }else
            printf("%c%c%c\n",a,a>c?'<':'>',c);
    }
}        