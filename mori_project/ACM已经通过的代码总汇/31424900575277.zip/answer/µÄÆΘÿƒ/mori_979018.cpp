 
//
//  main.cpp
//  排队
//
//  Created by Mori.William on 14-9-20.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int loop,n,m,sum;
    cin>>loop;
    while (loop--) {
        cin>>n>>m;
        sum = 0;
        for (int i = 2; i<=n; i++)
            sum = (m+sum)%i;
        cout<<sum+1<<endl;
    }
}        