 
#include<stdio.h>
int main()
{
    int n,i,j,x,k,y,l,m,s;
    scanf("%d",&n);
    while(n--)
    {
        int a[10001]={0};
        s=0;
        scanf("%d%d",&l,&m);
        for (i=0; i<=l;i++)
            a[i]=1;
        for(i=0;i<m;i++)
        {
            scanf("%d%d",&x,&y);
            for(j=x;j<=y;j++)
                a[j]=0;
        }
        for(k=0;k<=l;k++)
            if (a[k]==1)
                s++;
        printf("%d\n",s);
    }
    return 0;
}        