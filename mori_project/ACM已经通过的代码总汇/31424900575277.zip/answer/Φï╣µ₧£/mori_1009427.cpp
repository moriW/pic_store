 
//
//  main.cpp
//  苹果
//
//  Created by Mori.William on 14/10/18.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int main()
{
    int n,v,dp[1000],c[1000],p[1000];
    while (cin>>n>>v,n!=0 || v!=0) {
        for (int i = 1; i<=n; i++){
            cin>>c[i]>>p[i];
        }
        memset(dp, 0, sizeof(dp));
        
        for (int  i = 1; i<=n; i++)
            for (int j = v; j>=c[i]; j--)
                dp[j] = max(dp[j],dp[j-c[i]]+p[i]);
        cout<<dp[v]<<endl;
    }
}        