 
#include <stdio.h>
#include <iostream>
using namespace std;

int main()
{
    char a[200];
    while (gets(a)&&a[0]!=EOF) {
        int sum=0;
        for (int i=0; a[i]!='\0'; i++)
            sum+=a[i]=='a'?1:0;
        cout<<sum<<endl;
    }
}        