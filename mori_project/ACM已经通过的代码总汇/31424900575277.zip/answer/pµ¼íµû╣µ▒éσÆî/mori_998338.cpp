 
//
//  main.cpp
//  p次方求和
//
//  Created by Mori.William on 14-10-3.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//
#include <iostream>
using namespace std;

int quicksort(int q,int n)
{
    int basic = n;
    int sum = 1;
    while (q) {
        if (q&1) {
            sum *= basic;
            sum %= 10003;
        }
        basic *= basic;
        basic %= 10003;
        q>>=1;
    }
    return sum;
}

int main()
{
    int loop,n,m,sum;
    cin>>loop;
//    while (cin>>n>>m)
//        cout<<quicksort(n, m);
    
    while (loop--) {
        cin>>n>>m;
        sum = 0;
        for (int i = 1; i<=n; i++) {
            sum += quicksort(m, i);
            sum %= 10003;
        }
        cout<<sum<<endl;
        
    }
}        