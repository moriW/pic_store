 
//
//  main.cpp
//  p次方求和
//
//  Created by Mori.William on 14-10-3.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    
    int reslut[1001][1001],loop,n,m,sum;
    for (int i = 0; i<=1000; i++){
        
        reslut[i][0] = 1;
        reslut[i][1] = i;
        
        reslut[0][i] = 0;
        reslut[1][i] = 1;
    }
    
    
    for (int i = 2; i<=1000; i++)
        for (int j = 2; j<=1000; j++)
            reslut[i][j] = (reslut[i][j-1]*i)%10003;

    
    cin>>loop;
    while (loop--) {
        cin>>n>>m;
        sum = 0;
        for (int i = 1; i<=n; i++) {
            sum += reslut[i][m];
            sum %= 10003;
        }
        cout<<sum<<endl;
    }
}        