 
#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
    int a[10],n;
    a[0]=1;
    for (int i=1; i<10; i++) {
        a[i]=a[i-1]*(i+1);
        //printf("%d ",a[i]);
    }while (scanf("%d",&n)!=EOF) {
        printf("%d\n",a[n-1]);
    }
}        