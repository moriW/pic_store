 
//
//  main.cpp
//  小猴子下落
//
//  Created by Moridisa on 14-7-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int main()
{
    int d,n;
    while (cin>>d>>n,d!=0||n!=0) {
        int sum = 1;
        for (int i = 1; i<d; i++) {
            if ( n%2 != 0 ) {
                sum *= 2;
                n = (n+1)/2;
            } else {
                sum = (sum*2) + 1;
                n /= 2;
            }
            //cout<<sum<<endl;
        }
        cout<<sum<<endl;
    }
}        