 
//
//  main.cpp
//  括号配对
//
//  Created by Mori.William on 15/3/13.
//  Copyright (c) 2015年 Mori.William. All rights reserved.
//
#include <iostream>
#include <algorithm>
#include <stack>
#include <string>
using namespace std;

int main()
{
    int loop;
    cin>>loop;
    string s;
    char temp[10002];
    while (loop--) {
        cin>>s;
        int k = 0;
        for (int i = 0; i != s.length();i++) {
            temp[k] = s[i];
            if ( ( temp[k] == ')' && temp[k-1] == '(') || (temp[k]==']' && temp[k-1]=='['))
                k-=2;
            k++;
        }
        if (k == 0)
            cout<<"Yes"<<endl;
        else
            cout<<"No"<<endl;
    }
}        