 
//
//  main.c
//  括号配对
//
//  Created by Moridisa on 14-4-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <string.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        char a[10006],t[10006];
        scanf("%s",a);
        int j=0;
        if (strlen(a)%2) {
            printf("No\n");
            continue;
        }
        for (int i=0; a[i]!='\0'; i++) {
            t[j]=a[i];
            int c=0;
            if (j!=0) {
                if (t[j]==')'&&t[j-1]=='('){
                    j-=1;
                    c=1;
                }
                if (t[j]==']'&&t[j-1]=='['){
                    j-=1;
                    c=1;
                }
                
            }
            j+=c==1?0:1;
        }
        printf("%s\n",j==0?"Yes":"No");
    }
}        