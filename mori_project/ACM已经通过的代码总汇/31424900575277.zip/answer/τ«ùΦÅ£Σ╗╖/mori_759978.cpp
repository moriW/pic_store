 

#include <stdio.h>
#include <string.h>
int main()
{
    char name[50];
    double  value,count,all = 0;
    while (scanf("%s%lf%lf",name,&value,&count)!=EOF) {
        all=all+value*count;
    }
    printf("%3.1lf\n",all);
}        