 
//
//  main.cpp
//  numbers
//
//  Created by Mori.William on 15/4/12.
//  Copyright (c) 2015年 Mori.William. All rights reserved.
//


//
//  main.cpp
//  numbers
//
//  Created by Mori.William on 15/4/12.
//  Copyright (c) 2015年 Mori.William. All rights reserved.
//

#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdio>
using namespace std;



int getLen(long long temp)
{
    int count = 0;
    while (temp) {
        temp /= 10;
        count++;
    }
    return count;
}

void getString(long long temp,char a[])
{
    memset(a, 0, sizeof(a));
    int i = getLen(temp) - 1;
    a[i + 1] = '\0';
    while (temp) {
        a[i] = temp % 10 + '0';
        temp /= 10;
        i--;
    }
}

int main()
{
    long long n,k;
    char top[20],temp[20];
    while (cin>>n>>k, n != 0 || k != 0) {
        memset(top, 0, sizeof(top));
        for(int i = 0; i != getLen(n);i++){
            long long tem = ceil(pow(10, i) / k) * k;
            getString(tem, temp);
            
            if (i == 0) {
                strcpy(top, temp);
                continue;
            }
            
            if (strcmp(top,temp) > 0 && tem < n)
                strcpy(top,temp);
        }
        cout<<top<<endl;
    }
}        