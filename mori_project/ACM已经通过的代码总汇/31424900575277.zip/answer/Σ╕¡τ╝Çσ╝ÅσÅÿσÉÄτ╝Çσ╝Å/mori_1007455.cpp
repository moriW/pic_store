 
//
//  main.cpp
//  中缀式转后缀式
//
//  Created by Mori.William on 14-10-16.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <cstring>
#include <stack>
using namespace std;

bool jugeBigger(char a,char b)
{
    if (a=='=')
        return false;
    if (b=='(')
        return true;
    if (a=='+' || a=='-')
        if (b=='+'||b=='-'||b=='/'||b=='*')
            return false;
    if (a=='/'||a=='*')
        if (b=='/'||b=='*')
            return false;
    return true;
}

bool isOper(char a)
{
    if ((a<='9' && a>='0') || a=='.')
        return false;
    return true;
}

int main()
{
    stack<char> a,b;
    char str[1000];
    int len,loop;
    cin>>loop;
    while (loop--) {
        cin>>str;
        len = (int)strlen(str);
        for (int i = 0; i != len; ) {
            if (isOper(str[i])) {
                
                if (str[i]=='=') {
                    while (a.empty()==false) {
                        b.push(a.top());
                        b.push(' ');
                        a.pop();
                    }
                    b.push('=');
                    break;
                }
                
                if (str[i]=='(') {
                    a.push(str[i]);
                    i++;
                    continue;
                }
                
                while (str[i]==')' && a.top()!='(') {
                    b.push(a.top());
                    b.push(' ');
                    a.pop();
                }
                
                if (str[i]==')' && a.top()=='(') {
                    a.pop();
                    i++;
                    continue;
                }
                
                
                if (a.empty()==false) {
                    while (jugeBigger(str[i], a.top())==false) {
                        b.push(a.top());
                        b.push(' ');
                        a.pop();
                        if (a.empty())
                            break;
                    }
                    a.push(str[i]);
                    i++;
                    continue;
                } else {
                    a.push(str[i]);
                    i++;
                    continue;
                }
                
            }
            else{
                while (isOper(str[i])==false){
                    b.push(str[i]);
                    i++;
                }
                b.push(' ');
            }
        }
        while (b.empty()==false) {
            a.push(b.top());
            b.pop();
        }
        while (a.empty()==false){
            cout<<a.top();
            a.pop();
        }
        cout<<endl;
    }
}        