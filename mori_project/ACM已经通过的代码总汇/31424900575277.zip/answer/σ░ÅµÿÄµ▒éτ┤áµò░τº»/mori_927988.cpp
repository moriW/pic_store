 
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int main()
{
    int loop,n;
    bool sushu[1000];
    memset(sushu, true, sizeof(sushu));
    for (int i = 2; i!=1000; i++) {
        for (int j = 2*i; j<1000; j+=i)
            sushu[j] = false;
    }
    cin>>loop;
    while (loop--) {
        cin>>n;
        long long sum = 1;
        for (int i = 2; i <= n; i++) {
            if (sushu[i])
                sum = (sum*i)%1000000;
        }
        sum = sum%1000000;
        cout<<sum<<endl;
    }
}        