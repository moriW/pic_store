 
//
//  main.c
//  日期计算
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int days(int m)
{
    int day = 0;
    switch (m) {
        case 1:day=0;break;
        case 2:day=31; break;
        case 3:day=59; break;
        case 4:day=90; break;
        case 5:day=120;break;
        case 6:day=151;break;
        case 7:day=181;break;
        case 8:day=212;break;
        case 9:day=243;break;
        case 10:day=273;break;
        case 11:day=304;break;
        case 12:day=334;break;
    }
    return day;
}

int main()
{
    int loop,y,m,d;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d%d%d",&y,&m,&d);
        if ((y%4==0&&y%100!=0)||y%400==0) {
            d=d+days(m);
            if (m>2) {
                d++;
            }
        }else{d=d+days(m);}
        printf("%d\n",d);
    }
}        