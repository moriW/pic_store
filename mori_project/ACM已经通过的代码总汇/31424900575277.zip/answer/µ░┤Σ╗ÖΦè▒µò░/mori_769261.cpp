 
//
//  main.c
//  水仙花数
//
//  Created by Moridisa on 14-3-18.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int t,a,b,c;
    scanf("%d",&t);
    while(t!=0) {
        a=t/100;
        b=t/10-10*a;
        c=t-100*a-10*b;
        if (t==a*a*a+b*b*b+c*c*c) {
            printf("Yes\n");
        }else{printf("No\n");}
        scanf("%d",&t);
    }
}
        