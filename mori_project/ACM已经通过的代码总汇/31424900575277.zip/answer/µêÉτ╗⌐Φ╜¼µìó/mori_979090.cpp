 
//
//  main.cpp
//  成绩转换
//
//  Created by Mori.William on 14-9-21.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int n;
    while (cin>>n) {
        if (n>=90)
            cout<<'A'<<endl;
        else if (n>=80 && n<90)
            cout<<'B'<<endl;
        else if (n>=70 && n<80)
            cout<<'C'<<endl;
        else if (n>=60 && n<70)
            cout<<'D'<<endl;
        else
            cout<<'E'<<endl;
    }
}        