 
//
//  main.c
//  成绩转化
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int loop,sco;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&sco);
        if (sco>=90&&sco<=100) {
            printf("A\n");
        }if (sco>=80&&sco<=89) {
            printf("B\n");
        }if (sco>=70&&sco<=79) {
            printf("C\n");
        }if (sco>=60&&sco<=69) {
            printf("D\n");
        }if (sco>=0&&sco<=59) {
            printf("E\n");
        }
    }
}
        