 
//
//  main.cpp
//  茵茵的第一课
//
//  Created by Mori.William on 14-10-1.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    int loop;
    string a;
    cin>>loop;
    while (loop--) {
        cin>>a;
        cout<<a<<endl;
    }
}        