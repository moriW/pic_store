 
#include<stdio.h>

int main()
{
	int loop;
	scanf("%d\n",&loop);
	while(loop--){
		char s[20];
		gets(s);
		puts(s);
	}
}        