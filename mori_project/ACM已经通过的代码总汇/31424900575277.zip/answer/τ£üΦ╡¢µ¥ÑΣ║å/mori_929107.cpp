 
#include<iostream>
#include<stdio.h>
using namespace std;
int count(int a,int b);
int main()
{
    int m,n,s,k,t;
    while(scanf("%d%d",&m,&n)!=EOF)
    {
        s=1;
        k=m/n-1;
        t=m;
        while(k--)
        {
            s=s*count(t,n);
            t-=n;
            
        }
        s=s%2013;
        printf("%d\n",s);
    }
    printf("\n");
    return 0;
}
int count(int a,int b)
{
    int s=1,i,k=1;
    for(i=1;i<=b;i++)
        s=s*i;
    for(i=a;i>=(a-b+1);i--)
        k=k*i;
    return k/s;
}        