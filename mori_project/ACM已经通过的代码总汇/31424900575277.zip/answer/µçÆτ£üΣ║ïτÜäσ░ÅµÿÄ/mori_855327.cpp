 
#include<iostream>
#include<queue>
#include<vector>
#include<functional>
using namespace std;

int main()
{
    long long t,n,m,i,sum,a;
    //priority_queue<int, vector<int>, greater<int> > pq;
    cin>>t;
    while(t--){
        priority_queue<int, vector<int>, greater<int> > pq;
        sum=0;
        cin>>n;
        for(i=0;i<n;i++){
            cin>>m;
            pq.push(m);
        }
        
        while(pq.empty()!=true && n-1){
            a=pq.top();
            sum+=pq.top();
            //cout<<"第一个="<<pq.top()<<"     ";
            pq.pop();
            
            a+=pq.top();
            sum+=pq.top();
            //cout<<"第二个="<<pq.top()<<"     ";
            pq.pop();
            pq.push(a);
            //cout<<"a="<<a<<" "<<endl;
            n--;
            
        }
        
        cout<<sum<<endl;
    }
    return 0;
}        