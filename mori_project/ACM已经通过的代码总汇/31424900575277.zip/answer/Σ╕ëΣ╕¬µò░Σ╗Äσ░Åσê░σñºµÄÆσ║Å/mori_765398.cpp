 
//
//  main.c
//  三个数从小到大排序
//
//  Created by Moridisa on 14-3-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int a,b,c,t;
    scanf("%d%d%d",&a,&b,&c);
    if (a>b) {
        t=b;
        b=a;
        a=t;
    }if (b>c) {
        t=c;
        c=b;
        b=t;
    }if (a>b) {
        t=b;
        b=a;
        a=t;
    }printf("%d %d %d",a,b,c);
}
        