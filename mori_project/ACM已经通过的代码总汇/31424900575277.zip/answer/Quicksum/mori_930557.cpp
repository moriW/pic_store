 
#include <stdio.h>
#include <cstring>
int main()
{
    char a[1001];
    while (gets(a),a[0]!='#') {
        long long sum = 0;
        for (int i = 0; i!=strlen(a); i++) {
            if(a[i]!=' ')
                sum += (i+1) * (a[i]-64);
        }
        printf("%lld\n",sum);
        memset(a, 0, sizeof(a));
    }
}        