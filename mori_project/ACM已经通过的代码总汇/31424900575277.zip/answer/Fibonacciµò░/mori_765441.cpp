 
//
//  main.c
//  Fibonacci数
//
//  Created by Moridisa on 14-3-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int Fibonacci(int n)
{
    int a[20],i;
    a[0]=0,a[1]=1;
    for (i=1; i<=20; i++) {
        a[i]=a[i-1]+a[i-2];
        if (i==n) {
            break;
        }
    }return a[i];
}

int main(int argc, const char * argv[])
{
    int loop,n;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&n);
        if (n==1) {
            printf("1\n");
        }else{
        printf("%d\n",Fibonacci(n));
        }
    }
}
        