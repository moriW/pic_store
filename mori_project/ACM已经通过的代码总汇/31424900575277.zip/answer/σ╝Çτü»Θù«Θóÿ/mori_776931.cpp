 
//
//  main.c
//  开灯问题
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int n,k;
    scanf("%d%d",&n,&k);
    int t[n+1];
    for (int i=0; i<=n+1; i++) {
        t[i]=1;
    }for (int i=2; i<=k; i++) {
        for (int j=1; j*i<=n; j++) {
            t[i*j]++;
        }
    }for (int i=1; i<n+1; i++) {
        if (t[i]%2!=0) {
            printf("%d ",i);
        }
    }
}        