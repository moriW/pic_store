 
#include <iostream>
using namespace std;
int main()
{
    int n,t;
    cin>>t;
    while(t--){
        cin>>n;
        cout<<2*n*n-n+1<<endl;
    }
    return 0;
}        