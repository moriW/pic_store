 
//
//  main.c
//  a letter and a number
//
//  Created by Moridisa on 14-4-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <stdio.h>

int main()
{
    int lo;
    scanf("%d",&lo);
    while (lo--){
        char s;
        int n;
        getchar();
        scanf("%c%d",&s,&n);
        if (s>96) {
            s=96-s;
        }else{
            s-=64;
        }
        printf("%d\n",s+n);
    }
}        