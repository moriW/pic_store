 
#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int loop;
    cin>>loop;
    while (loop--) {
        int n;
        cin>>n;
        int a,b,c;
        int x=0,y=99999999,z=0;
        for (int i=0; i<n; i++) {
            cin>>a>>b>>c;
            //cout<<a<<' '<<b<<' '<<c<<endl;
            if (a>x) {
                x=a;
                y=b;
                z=c;
            }
            if (a==x&&b<y) {
                x=a;
                y=b;
                z=c;
            }
            if (a==x&&b==y&&c>z) {
                x=a;
                y=b;
                z=c;
            }
            //cout<<x<<' '<<y<<' '<<z<<endl;
        }
        cout<<z<<endl;;
    }
}        