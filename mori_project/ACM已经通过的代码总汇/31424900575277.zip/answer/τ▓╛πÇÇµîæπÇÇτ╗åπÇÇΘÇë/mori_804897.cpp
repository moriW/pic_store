 
//
//  main.c
//  精挑细选
//
//  Created by Moridisa on 14-3-30.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <stdio.h>

int pao(int a[],int n,int dx)
{
    int b[n];
    for (int i=0; i<n; i++) {
        b[i]=a[i];
    }for (int i=0; i<n; i++) {
        for (int j=i+1; j<n; j++) {
            if (b[i]>b[j]) {
                b[i]+=b[j];
                b[j]=b[i]-b[j];
                b[i]-=b[j];
            }
        }
    }if (dx==1) {
        return b[n-1];
    }else{
        for (int i=0; i<n; i++) {
            if (b[i]!=0) {
                b[0]=b[i];
                break;
            }
        }return b[0];
    }
}

void dele(int a[],int b[],int c[],int n,int juge)
{
    for (int i=0; i<n; i++) {
        if (a[i]!=juge) {
            a[i]=b[i]=c[i]=0;
        }
    }
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n,maxL,maxC,maxX;
        scanf("%d",&n);
        int a[n],b[n],c[n];
        for (int i=0; i<n; i++) {
            scanf("%d%d%d",&a[i],&b[i],&c[i]);
        }maxL=pao(a,n,1);
        dele(a,b, c, n,maxL);
        maxC=pao(b, n, 0);
        dele(b, a, c, n, maxC);
        maxX=pao(c, n, 1);
        printf("%d\n",maxX);
    }
}        