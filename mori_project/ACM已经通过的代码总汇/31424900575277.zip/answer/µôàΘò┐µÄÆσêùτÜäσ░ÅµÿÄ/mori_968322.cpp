 


#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

int main()
{
    int t,n,m,i,temp;
    int a[8]={1,2,3,4,5,6,7,8};
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        temp=0;
        do
        {
            if(temp!=a[m-1])
            {
                for(i=0;i<m;i++)
                    printf("%d",a[i]);
                printf("\n");
                temp=a[m-1];
            }
        }while(next_permutation(a,a+n));
    }
}        