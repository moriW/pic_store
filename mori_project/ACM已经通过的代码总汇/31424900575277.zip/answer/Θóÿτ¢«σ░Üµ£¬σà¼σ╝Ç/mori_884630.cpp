 
#include <algorithm>
#include <iostream>

using   namespace   std;

int main()
{
    int n;
    cin>>n;
    while (n--) {
        int a[10];
        for (int i=0; i<10; i++)
            cin>>a[i];
        sort(a, a+10);
        cout<<a[7]<<endl;
    }
}        