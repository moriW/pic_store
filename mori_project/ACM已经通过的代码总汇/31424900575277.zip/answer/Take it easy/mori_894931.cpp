 
//
//  main.cpp
//  Take it easy
//
//  Created by Moridisa on 14-6-12.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int n;
    while (cin>>n) {
        int a,sum=0;
        for (int i=0; i<10; i++) {
            if (n==0){
                cin>>a;
                continue;
            }
            cin>>a;
            n+=a;
            //cout<<sum<<endl;
            sum++;
        }
        cout<<sum<<endl;
    }
}
        