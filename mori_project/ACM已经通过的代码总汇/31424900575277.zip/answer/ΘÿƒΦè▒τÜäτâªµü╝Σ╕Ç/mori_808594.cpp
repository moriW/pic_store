 
#include <stdio.h>

int main()
{
    int n;
    while (scanf("%d",&n)!=EOF) {
        int s[30]={0},yu,t=0;
        if (n==0) {
            printf("0\n");
            continue;
        }
        while (n) {
            yu=n%2;
            n/=2;
            s[t]=yu;
            t++;
        }for (t=29; s[t]==0; t--);
            for (int j=t; j>=0; j--) {
                printf("%d",s[j]);
            }
        printf("\n");
    }
}        