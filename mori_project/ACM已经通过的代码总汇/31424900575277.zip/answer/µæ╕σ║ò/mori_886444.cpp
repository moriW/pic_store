 
#include"stdio.h"
#include"algorithm"
using namespace std;

int main()
{
int N,num[7];
scanf("%d",&N);
while(N --)
{
for(int i = 0;i <= 6;i ++)
{
scanf("%d",&num[i]);
}
sort(num,num + 7);
double u = (num[0] + num[6] + num[3]) / 3.0;
printf("%.2lf\n",u);
}
return 0;
}        