 
#include<iostream>
#include <algorithm>
#include <cstdio>
//from coder mori
using namespace std;

int main()
{
    int n,a[7];
    //freopen("c.txt","r",stdin);
    scanf("%d",&n);
    while(n--){
        for(int i=0;i<7;i++)
            scanf("%d",&a[i]);
        sort(a,a+7);
        double t=(a[0]+a[3]+a[6])/3.0;
        printf("%.2lf\n",t);
    }
    return 0;
}
        