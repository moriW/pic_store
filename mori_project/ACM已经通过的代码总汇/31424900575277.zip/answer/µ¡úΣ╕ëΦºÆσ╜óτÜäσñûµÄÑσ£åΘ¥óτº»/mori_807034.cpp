 
#include <stdio.h>
#include <math.h>
#define PI 3.1415926
int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        double x;
        scanf("%lf",&x);
        printf("%.2lf\n",PI*x*x/3);
    }
}        