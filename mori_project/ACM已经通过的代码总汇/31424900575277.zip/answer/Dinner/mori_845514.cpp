 
//
//  main.cpp
//  Dinner
//
//  Created by Moridisa on 14-4-30.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <string.h>


char tableware[4][20]={"bowl","knife","fork","chopsticks"};

int main()
{
    int n;
    while (scanf("%d",&n)!=EOF) {
        char a[20];
        for (int i=0; i<n; i++) {
            scanf("%s",a);
            for (int i=0; i<4; i++) {
                if (strcmp(tableware[i],a)==0)
                    printf("%s ",a);
            }
        }printf("\n");
    }
}        