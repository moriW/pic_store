 
//
//  main.cpp
//  skiing
//
//  Created by Mori.William on 14-10-14.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>
#include <cstring>
#define max(a,b) a>b?a:b

int xplus[] = {0,1,0,-1};
int yplus[] = {1,0,-1,0};
int height[100][100],dp[100][100];
int x,y;

bool inside(int gx,int gy)
{
    if ( 0 <= gx && gx < x && 0 <= gy && gy<y)
        return true;
    return false;
}

int dfs(int gx,int gy)
{
    int max = 1;
    if (dp[gx][gy]>1) {
        return dp[gx][gy];
    }
    else {
        for (int i = 0; i<4; i++) {
            int nx = gx + xplus[i];
            int ny = gy + yplus[i];
            if (inside(nx, ny) && height[gx][gy] > height[nx][ny]){
                dp[gx][gy] = dfs(nx, ny) + 1;
                if (dp[gx][gy]>max)
                    max = dp[gx][gy];
            }
        }
    }
    dp[gx][gy] = max;
    return  max;
}

int main()
{
    int loop,maxlen;
    scanf("%d",&loop);
    while (loop--) {
        maxlen = 0;
        memset(height, 0, sizeof(height));
        scanf("%d%d",&x,&y);
        
        for (int i = 0; i!=x; i++){
            for (int j = 0; j!=y; j++){
                scanf("%d",&height[i][j]);
                dp[i][j] = 1;
            }
        }
//        
//        for (int i = 0; i!=x; i++) {
//            for (int j = 0; j!=y; j++) {
//                printf("%d ",height[i][j]);
//            }
//            printf("\n");
//        }
        
        for (int i = 0; i!=x; i++)
            for (int j = 0; j!=y; j++)
                maxlen = max(maxlen,dfs(i,j));
//        
//        for (int i = 0; i!=x; i++) {
//            for (int j = 0; j!=y; j++) {
//                printf("%d ",dp[i][j]);
//            }
//            printf("\n");
//        }
//    
        
        printf("%d\n",maxlen);
    }
}        