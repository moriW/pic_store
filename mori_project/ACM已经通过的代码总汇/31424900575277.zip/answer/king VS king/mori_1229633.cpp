 
 

//
//  main.cpp
//  c++萌萌哒
//
//  Created by t.y. on 15/3/12.
//  Copyright (c) 2015年 ___FULLUSERNAME__. All rights reserved.
//
//65


#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int t;
    cin>> t;
    while (t--)
    {
        int n,i,j,x = 0,y = 0;
        cin>> n;
        int a[n],b[n];
        for (i=0; i<n; i++)
            cin>> a[i];
        for (i=0; i<n; i++)
            cin>> b[i];
        sort(a,a+n);
        sort(b,b+n);
        for (i=0; i<n; i++)
        {
            if (a[i]>b[i])
                x++;
            else if (a[i]<b[i])
                y++;
        }
        if (x>y)
            cout<< "X" <<endl;
        else if (x<y)
            cout<< "Y" <<endl;
        else
            cout<< "none" <<endl;
        
    }
}                