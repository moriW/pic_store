 
#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{
    int loop;
    cin>>loop;
    while (loop--) {
        int n,a,b,sum1=0,sum2=0;
        cin>>n;
        for (int i=0; i<n; i++){
            cin>>a;
            sum1+=a;
        }
        for (int i=0;i<n;i++){
            cin>>b;
            sum2+=b;
        }if (sum1==sum2)
            printf("none\n");
        else
            printf("%c\n",sum1>sum2?'X':'Y');
    }
}        