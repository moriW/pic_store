 
//
//  main.c
//  a letter and a number
//
//  Created by Moridisa on 14-4-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <stdio.h>
#include <math.h>

int fanz(int a)
{
    int t=0,b=a;
    while (b>0) {
        b/=10;
        t++;
    }b=0;t--;
    while (a>0) {
        b+=(a%10)*pow(10, t);
        a/=10;
        t--;
    }return b;
}

int main()
{
    int a,b=0;
    while (scanf("%d%d",&a,&b)&&(a!=0||b!=0)) {
        printf("%d\n",fanz(a)+fanz(b));
    }
}        