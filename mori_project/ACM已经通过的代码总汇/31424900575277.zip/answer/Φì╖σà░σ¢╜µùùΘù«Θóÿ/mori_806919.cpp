 
#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        getchar();
        int r=0,w=0,b=0;
        char s[1001];
        scanf("%s",s);
        for (int i=0; s[i]!='\0'; i++) {
            switch (s[i]) {
                case 'R':r++;break;
                case 'B':b++;break;
                case 'W':w++;break;
            }
        }while (r--) {
            printf("R");
        }while (w--) {
            printf("W");
        }while (b--) {
            printf("B");
        }printf("\n");
    }
}        