 
#include<stdio.h>
#include<string.h>
struct byq
{
    char str[101];
}w[10001];
int main()
{
    int s,n,i,k,count;
    char ch,a[10001];
    scanf("%d",&s);
    while(s--)
    {
        memset(w,0,sizeof(w));
        count=0;k=0;
        scanf("%d",&n);
        for(i=0;i<=n-1;i++)
            scanf("%s",w[i].str);
        while(scanf("%c",&ch)&&ch!='@')  {
            if((ch>='a'&&ch<='z')||(ch>='0'&&ch<='9')||ch=='_')
                a[k++]=ch;
            else  {
                for(i=0;i<n;i++)
                    if(strcmp(a,w[i].str)==0)
                        count++;
                memset(a,0,sizeof(a));
                k=0;
            }
        }
        printf("%d\n",count);
    }
    return 0;
}
        