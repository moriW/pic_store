 
#include <stdio.h>
int main()
{
    int a,b;
    while (scanf("%d%d",&a,&b),a!=0&&b!=0) {
        int x,y,juge=0;
        x=a-1;
        y=1;
        while (x>0) {
            if (x*y==b) {
                juge=1;
            }x--;y++;
        }if (juge==1) {
            printf("YES\n");
        }else{
            printf("NO\n");
        }
    }
}        