 
//
//  main.c
//  两点距离
//
//  Created by Moridisa on 14-3-23.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <math.h>

int main()
{
    int loop;
    float x1,x2,y1,y2,s;
    scanf("%d",&loop);
    while (loop--){
        scanf("%f%f%f%f",&x1,&y1,&x2,&y2);
        s=sqrtf((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
        printf("%.2lf\n",s);
    }
}        