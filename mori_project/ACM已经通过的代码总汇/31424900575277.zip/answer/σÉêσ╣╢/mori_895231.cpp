 
//
//  main.cpp
//  合并
//
//  Created by Moridisa on 14-6-2.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <stdio.h>
using namespace std;

int main()
{
    int loop,n,b;
    cin>>loop;
    while (loop--) {
        cin>>n;
        int *a=(int *)malloc(sizeof(int)*2*n);
        for (int i=0; i<n*2; i++)
            a[i]=-1;
        for (int i=0; i<2*n; i++) {
            cin>>b;
            a[i]=b;
            for (int j=i-1; j>=0; j--) {
                if (a[j]==a[i])
                    a[i]=-1;
            }
        }
        sort(a, a+2*n);
        for (int i=0; i<2*n; i++) {
            if (a[i]!=-1)
                cout<<a[i]<<' ';
        }
        cout<<endl;
        free(a);
    }
}        