 
#include <iostream>
#include <stdio.h>
#include <memory.h>
using namespace std;

int main()
{
    bool a[1020];
    memset(a, true, sizeof(a));
    for (int i=2; i<=1000; i++)
        for (int j=i*2; j<=1000; j+=i)
            a[j]=false;
    int loop;
    cin>>loop;
    while (loop--) {
        int n,t,k,i,j;
        cin>>n;
        if (n==1) {
            printf("2\n");
            continue;
        }
        if (a[n]){
            printf("%d\n",n);
            continue;
        }
        for (i=n; i>=2; i--){
            if (a[i])
                break;
        }
        for (j=n; j<1000; j++) {
            if (a[j])
                break;
        }
        if (n>=999){
            printf("997\n");
            continue;
        }
        if (n-i>=j-n) {
            printf("%d\n",j);
        }else
            printf("%d\n",i);
    }
}        