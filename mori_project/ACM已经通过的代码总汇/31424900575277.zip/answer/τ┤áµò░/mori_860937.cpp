 
#include <stdio.h>

int main()
{
    int a[1009]={0},i,j,x,t,m,n;
    for(i=2;i<=1000;i++){
        for(j=i*2;j<=1000;j+=i){
            a[j]=1;
        }
    }
    scanf("%d",&n);
    while(n--){
        scanf("%d",&x);
        if (x==1) {
            printf("2\n");
            continue;
        }
        if(a[x]==0){
            printf("%d\n",x);
            continue;
        }
        if (x>=998) {
            printf("997\n");
            continue;
        }
        for(j=x;j>=2;j--)
        {
            if(a[j]==0){
                t=j;
                break;
            }
        }
        for(j=x;j<1000;j++)
        {
            if(a[j]==0){
                m=j;
                break;
            }
        }
        if((m-x)<=(x-t))
            printf("%d\n",m);
        else
            printf("%d\n",t);
    }return 0;
}
        