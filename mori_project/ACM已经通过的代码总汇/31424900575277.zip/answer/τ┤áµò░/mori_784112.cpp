 
//
//  main.c
//  素数
//
//  Created by Moridisa on 14-3-26.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int juge(int num)
{
    int juge;
    if (num==0) {
        juge=0;
    }if (num==2) {
        juge=1;
    }if (num==3) {
        juge=1;
    }
    else{
        for (int i=2; i*i<=num; i++) {
            if (num%i!=0) {
                juge=1;
            }if (num%i==0) {
                juge=0;
                break;
            }
        }
    }return juge;
}

int main()
{
    int loop,n,i,j;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&n);
        if (juge(n)==1) {
            printf("%d\n",n);
        }else{
            for (i=1; n-i>0; i++) {
                if (juge((n-i))==1) {
                    break;
                }
            }for (j=1; n+j<2*n; j++) {
                if (juge((n+j))==1) {
                    break;
                }
            }if (j<=i) {
                printf("%d\n",n+j);
            }else{
                printf("%d\n",n-i);
            }
        }
    }
}        