 
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <queue>
using namespace std;

int main()
{
    long long Max,Min,location,sum,temp,temp1,temp2,n;
    while(cin>>n){
        sum   = 0;
        for(int i = 0; i != n ; i++){
            cin>>temp;
            if(i==0){
                temp1 = temp;
                temp2 = temp;
                Max = temp;
                Min = temp;
                sum = sum + temp;
            }
            else{
                temp1 = max(temp + temp1,temp);
                temp2 = min(temp + temp2,temp);
                Max   = max(Max,temp1);
                Min   = min(Min,temp2);
                sum   = sum + temp;
            }
            //cout<<Max<<' '<<Min<<' '<<sum<<endl;
        }
        if(Max<0&&sum<0)
            Max = min(Max,sum-Min);
        else
            Max = max(Max,sum-Min);
        cout<<Max<<endl;
    }
}
        