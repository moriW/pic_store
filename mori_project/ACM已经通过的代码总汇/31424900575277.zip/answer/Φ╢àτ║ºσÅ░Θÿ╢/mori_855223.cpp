 
//
//  main.cpp
//  超级台阶
//
//  Created by Moridisa on 14-5-7.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <stdio.h>

int main()
{
    int s[45];
    s[0]=0,s[1]=1;s[2]=1;
    for (int i=3; i<43; i++)
        s[i]=s[i-1]+s[i-2];
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n;
        scanf("%d",&n);
        printf("%d\n",n==1?0:s[n]);
    }
}        