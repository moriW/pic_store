 
//
//  main.cpp
//  我排第几个
//
//  Created by mori on 14-9-13.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//


#include <iostream>
using namespace std;

int main()
{
    int loop,sum,n,fac[]={0,1,2,6,24,120,720,5040,40320,362880,3628800,39916800};
    char str[12];
    cin>>loop;
    while (loop--) {
        cin>>str;
        sum = 0;
        
        for (int i = 0; i!=12; i++) {
            n = 0;
            for (int j = i+1; j!=12; j++)
                if (str[i]>str[j])
                    n++;
            sum += fac[11-i] * n;
        }
        cout<<sum+1<<endl;
    }
    
}        