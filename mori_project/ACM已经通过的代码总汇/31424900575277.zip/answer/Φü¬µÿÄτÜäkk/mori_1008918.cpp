 
//
//  main.cpp
//  聪明的KK
//
//  Created by Mori.William on 14-10-17.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <algorithm>

int num[500][500];
int dp[500][500];
int mx[] = {1,0},my[] = {0,1},n,m;
using namespace std;

int dfs(int x,int y)
{
    if (x==n-1 && y==m-1)
        return dp[x][y]=num[x][y];
    if (dp[x][y]!=-1)
        return dp[x][y];
    for (int i = 0; i!=2; i++) {
        int dx = x + mx[i];
        int dy = y + my[i];
        if (dfs(dx, dy) + num[x][y] > dp[x][y] && dx<n && dy < m )
            dp[x][y] = dp[dx][dy] + num[x][y];
    }
    return dp[x][y];
}

int main()
{
    while (cin>>n>>m) {
        for (int i = 0; i!=n; i++)
            for (int j = 0; j!=m; j++){
                cin>>num[i][j];
                dp[i][j] = -1;
            }
        cout<<dfs(0, 0)<<endl;
    }
    return 0;
}
        