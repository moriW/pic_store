 
#include <stdio.h>

int main()
{
    int lo;
    scanf("%d",&lo);
    while (lo--) {
        int hs,cs=0;
        float   realtime=0;
        scanf("%d",&hs);
        while (hs--) {
            float time;
            char s[5];
            scanf("%s",s);
            switch (s[0]) {
                case 'I':cs++;break;
                case 'S':scanf("%f",&time);
                    for (int t=cs; t>0; t--) {
                        time/=20;
                    }realtime+=time*60;
                    break;
                case 'O':cs--;break;
            }
        }printf("%.0f\n",realtime);
    }
}        