 
//
//  main.c
//  C小加
//
//  Created by Moridisa on 14-4-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

void    maop(int n,int a[])
{
    for (int i=0; i<n; i++) {
        for (int j=i+1; j<n; j++) {
            if (a[i]>a[j]) {
                a[i]+=a[j];
                a[j]=a[i]-a[j];
                a[i]-=a[j];
            }
        }
    }
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n,d;
        scanf("%d",&n);
        d=0;
        int a[n];
        for (int i=0;i<n;i++) {
            scanf("%d",&a[i]);
        }maop(n,a);
        for (int i=0; i<n; i++) {
            int j=i+1;
            if (a[i]==a[j]) {
                a[i]=0;
                d++;
            }
        }maop(n,a);
        printf("%d\n",n-d);
        for (int i=0; i<n; i++) {
            if (a[i]!=0) {
                printf("%d ",a[i]);
            }
        }printf("\n");
    }
}        