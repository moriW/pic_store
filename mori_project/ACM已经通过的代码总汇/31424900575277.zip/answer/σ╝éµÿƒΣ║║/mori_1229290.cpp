 
#include <stdio.h>
#include <math.h>
#define min(a,b) a<b?a:b
#define max(a,b) a>b?a:b
int main()
{
    int loop;
    double v0,v1,a0,a1,x,result,derta,a,b,c,temp1,temp2;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%lf%lf%lf%lf%lf",&v0,&a0,&v1,&a1,&x);
        
        a = a0-a1;
        b = 2*(v0-v1);
        c = -2*x;
        
        if (a0 == a1) {
            if (v0 > v1) {
                result = (-1 * b) / (2 * a);
                printf("%.2lf\n",result);
            }
            else
                printf("Drong is strong.\n");
            continue;
        }
        
        derta = b * b - 4 * a * c;
        if (derta>0){
            temp1 = ( -b + sqrt(derta)) / (2*a);
            temp2 = ( -b - sqrt(derta)) / (2*a);
            
            if (temp1>0) {
                if (temp2>0)
                    printf("%.2lf\n",min(temp1, temp2));
                else
                    printf("%.2lf\n",temp1);
            }
            else{
                if (temp2 > 0)
                    printf("%.2lf\n",temp2);
                else
                    printf("Drong is strong.\n");
            }
            
        }
        else
            printf("Drong is strong.\n");
    }
}        