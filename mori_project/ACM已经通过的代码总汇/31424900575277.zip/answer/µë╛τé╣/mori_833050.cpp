 
#include <stdio.h>

void Pai(int a[],int n)//按照间距排序
{
	int i,j;
	for(i=0;i<2*n;i+=2){
		for(j=i+2;j<2*n;j+=2){
			if(a[i+1]>a[j+1]){
				int t=a[i+1];
				a[i+1]=a[j+1];
				a[j+1]=t;
				t=a[i];
				a[i]=a[j];
				a[j]=t;
			}
		}
	}
}

int dian(int a[],int n)//找点
{
	int i,j,k=a[1],point=1;
	for(i=0;i<2*n;i+=2){
		if(a[i]>k){
			point++;
			k=a[i+1];
		}
	}
	return point;
}

int main()
{
	int n,a[200],i,j;
	while(scanf("%d",&n)!=EOF){
		if(n==0)
			continue;
		for(i=0;i<2*n;i++)
			scanf("%d",&a[i]);
		Pai(a,n);
		printf("%d\n",dian(a,n));
	}
	return 0;
}
        