 
//
//  main.c
//  16进制加减
//
//  Created by Moridisa on 14-4-10.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int a,b;
        char c;
        scanf("%x%c%x",&a,&c,&b);
        if (c=='-') {
            printf("%o\n",a-b);
        }if (c=='+') {
            printf("%o\n",a+b);
        }
    }
}        