 
//
//  main.cpp
//  单调递增最长子序列
//
//  Created by Mori.William on 14-10-8.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//


#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;

int main()
{
    int loop,dp[10001],len,ans;
    char str[10001];
    cin>>loop;
    while (loop--) {
        cin>>str;
        ans = 0;
        len = (int)strlen(str);
        
        for (int i = len-1; i >= 0; i--){
            dp[i] = 1;
            for (int j = len-1; j>i; j--){
                if (str[i]<str[j])
                    dp[i] = max(dp[i], dp[j]+1);
            }
            ans = max(ans, dp[i]);
        }
//        for (int i = 0; i!=len; i++)
//            cout<<dp[i]<<' ';
//        cout<<endl;
//        
        cout<<ans<<endl;
    }
}        