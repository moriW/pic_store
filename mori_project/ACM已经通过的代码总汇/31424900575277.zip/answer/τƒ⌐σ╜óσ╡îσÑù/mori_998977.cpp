 
//
//  main.cpp
//  矩形嵌套
//
//  Created by Mori.William on 14-10-8.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>
#include <algorithm>
#include <cstdlib>
using namespace std;

struct jx{
    int x,y;
};

bool compare(struct jx a,struct jx b)
{
    if (a.x==b.x)
        return a.y<b.y;
    return a.x<b.x;
}

int main()
{
    int n,loop,sum,*dp;
    scanf("%d",&loop);
    while (loop--) {
        
        sum = 0;
        scanf("%d",&n);
        jx *p = (jx *)malloc(sizeof(jx)*n);
        dp = (int *)malloc(sizeof(int)*n);
        
        
        for (int i = 0; i!=n; i++){
            scanf("%d%d",&p[i].x,&p[i].y);
            if (p[i].y>p[i].x) {
                swap(p[i].x, p[i].y);
            }
        }
        sort(p, p+n, compare);

        
//        printf("\n\n\n");
//        for (int i = 0; i!=n; i++)
//            printf("%d %d\n",p[i].x,p[i].y);
//        printf("\n");
        
        for (int i = 0; i!=n; i++){
            dp[i] = 1;
            for (int j = 0; j!=i; j++)
                if (p[i].x > p[j].x && p[i].y > p[j].y && dp[i] < dp[j] + 1)
                    dp[i] = dp[j] + 1;
        }
        
        
        for (int i = 0; i!=n; i++)
            if (dp[i]>sum)
                sum = dp[i];
        
        printf("%d\n",sum);
        
    }
}        