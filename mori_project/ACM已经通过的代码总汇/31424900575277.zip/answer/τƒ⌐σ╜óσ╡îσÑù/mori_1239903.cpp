 
#include <cstdio>
#include <algorithm>
using namespace std;

struct juxing{
    int kuan,chang;
}jx[100];

bool cmp(juxing a, juxing b)
{
    if(a.kuan != b.kuan )
        return a.kuan > b.kuan;
    return a.chang > b.chang;
}

int main()
{
    int loop,n,chang,kuan,dp[100],Max;
    scanf("%d",&loop);
    while(loop--){
        Max = 0;
        scanf("%d",&n);
        for(int i = 0; i != n ; i++){
            scanf("%d%d",&kuan,&chang);
            if(kuan > chang)
                swap(kuan,chang);
            jx[i].kuan = kuan;
            jx[i].chang = chang;
        }
        sort(jx,jx+n,cmp);
        for(int i = 0;i != n ;i++){
            dp[i] = 1;
            for(int j = 0; j != i;j++){
                if(jx[i].kuan < jx[j].kuan && jx[i].chang < jx[j].chang)
                    dp[i] = max(dp[i],dp[j]+1);
            }
        }

        for(int i = 0;i != n ;i++)
            Max = max(Max,dp[i]);
        printf("%d\n",Max);
    }
}
        