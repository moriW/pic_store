 
#include <stdio.h>
bool juge[1000010] = {false};

int main()
{
    int loop,temp;
    juge[0] = true;
    juge[1] = true;
    
    for (int i = 2; i != 1000010; i ++)
        if (!juge[i])
            for (int j = i * 2; j < 1000010; j += i)
                juge[j] = true;
    
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&temp);
        if (temp == 0) {
            printf("2 2\n");
            continue;
        }
        int distance = 0;
        while (1) {
            if (!juge[temp - distance]) {
                printf("%d %d\n",temp - distance,distance);
                break;
            }
            if (!juge[temp + distance]) {
                printf("%d %d\n",temp + distance,distance);
                break;
            }
            distance++;

        }
    }
    
}        