 
//
//  main.c
//  素数间距
//
//  Created by Moridisa on 14-3-17.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int juge(int num)
{
    int juge;
    if (num==1) {
        juge=0;
    }if (num==2) {
        juge=1;
    }if (num==3) {
        juge=1;
    }
    else{
        for (int i=2; i*i<=num; i++) {
            if (num%i!=0) {
                juge=1;
            }if (num%i==0) {
                juge=0;
                break;
            }
        }
    }return juge;
}

int main()
{
    int loop,num,i;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&num);
        if (num==1) {
            printf("2 1\n");
            continue;
        }if (num==0) {
            printf("2 2");
            continue;
        }
        if (juge(num)==1) {
            printf("%d 0\n",num);
        }if (juge(num)!=1) {
            int a[num];
            for (i=1; i<num; i++) {
                a[num/2]=num;
                a[num/2-i]=num-i;
                a[num/2+i]=num+i;
                if (juge(a[num/2-i])==1) {
                    printf("%d %d\n",a[num/2-i],num-a[num/2-i]);
                    break;
                }if (juge(a[num/2+i])==1) {
                    printf("%d %u\n",a[num/2+i],a[num/2+i]-num);
                    break;
                }
            }
        }
    }
}

        