 
//
//  main.cpp
//  nothing here
//
//  Created by Moridisa on 14-7-1.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//


#include<stdio.h>
#include<algorithm>
#include<iostream>
using namespace std;
struct node{
    int x, y;
}G[5005];
int cmp(node a, node b){
    if(a.x != b.x)
        return a.x > b.x;
    else
        return a.y > b.y;
}
int main(){
    int chiose, N, i, j, t;
    scanf("%d", &chiose);
    while(chiose--){
        int count = 0;
        scanf("%d", &N);
        for(i = 0; i < N; i++)
            scanf("%d%d", &G[i].x, &G[i].y);
        
        
        sort(G, G + N, cmp);
        
        //for (int i=0; i<N; i++) {
            //printf("%d %d\n",G[i].x,G[i].y);
        //}
        
        for(i = 0; i < N; i++){
            if(G[i].y > -1){
                count++;
                t = G[i].y;
                for(j = i + 1; j <= N; j++){
                    if(t >= G[j].y && G[j].y > -1){
                        t = G[j].y;
                        G[j].y = -1;
                    }
                }
            }
        }
        printf("%d\n", count);
    }
    return 0;
}        