 

//
//  main.cpp
//  不信邪试试C++
//
//  Created by Moridisa on 14-6-28.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

struct stick
{
    int len,wei;
};

bool cmp(struct stick x,struct stick y)
{
    if (x.len==y.len)
        return x.wei>y.wei;
    return x.len>y.len;
}

int main()
{
    int loop,n;
    scanf("%d",&loop);
    while (loop--) {
        int sum = 0 , g;
        scanf("%d",&n);
        stick *a = new stick[n];
        for (int i=0; i<n; i++)
            scanf("%d%d",&a[i].len,&a[i].wei);
        /*
        for (int i=0; i<n; i++)
            cout<<a[i].len<<' '<<a[i].wei<<endl;
        */
        
        
        sort(a, a+n, cmp);
        for (int i=0; i<n; i++) {
            if (a[i].wei>-1) {
                g=a[i].wei;
                sum++;
                for (int j=i+1; j<n; j++) {
                    if ( a[j].wei > -1 && g >= a[j].wei) {
                        g=a[j].wei;
                        a[j].wei=-1;
                    }
                }
            }
        }
        cout<<sum<<endl;
        delete [] a;
    }
    return 0;
}        