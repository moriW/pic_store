 
//
//  main.cpp
//  九的余数
//
//  Created by Mori.William on 14-9-17.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>
#include <cstring>
int main()
{
    int loop,n;
    char num[1000000];
    scanf("%d",&loop);
    while (loop--) {
        n = 0;
        scanf("%s",num);
        for (int i = (int)strlen(num)-1; i!=-1; i--) {
            n += num[i] - '0';
            n %= 9;
        }
        printf("%d\n",n);
    }
}        