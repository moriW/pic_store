 
#include <string.h>
#include <stdio.h>

int main()
{
    char a[1001],b[1001];
    while (scanf("%s%s",a,b),a[0]!='0'||b[0]!='0') {
        //printf("%s %s\n",a,b);
        if (a[0]=='-'&&b[0]!='-') {
            printf("a<b\n");
            continue;
        } else if (b[0]=='-'&&a[0]!='-') {
            printf("a>b\n");
            continue;
        } else {
            if (a[0]=='-') {
                if (strlen(a)<strlen(b))
                    printf("a>b\n");
                else if (strlen(a)>strlen(b))
                    printf("a<b\n");
                else {
                    if (strcmp(a, b)==0) {
                        printf("a==b\n");
                    } else if(strcmp(a, b)>0)
                        printf("a<b\n");
                    else
                        printf("a>b\n");
                }
            } else {
                if (strlen(a)>strlen(b))
                    printf("a>b\n");
                else if(strlen(a)<strlen(b))
                    printf("a<b\n");
                else{
                    if (strcmp(a, b)>0)
                        printf("a>b\n");
                    else if (strcmp(a, b)<0)
                        printf("a<b\n");
                    else
                        printf("a==b\n");
                }
            }
        }
    }
}        