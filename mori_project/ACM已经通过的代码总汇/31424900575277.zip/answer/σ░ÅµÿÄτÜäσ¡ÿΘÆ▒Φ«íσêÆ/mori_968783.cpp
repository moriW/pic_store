 
//
//  main.cpp
//  小明的存钱计划
//
//  Created by Moridisa on 14-9-6.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//


#include <cstdio>

int main()
{
    int loop,sum,cun,a[12],i;
    scanf("%d",&loop);
    while (loop--) {
        sum = 0;
        cun = 0;
        
        for (int i = 0;i!=12; i++)
            scanf("%d",&a[i]);
        
        for (i = 0; i!=12; i++) {
            sum += 300 - a[i];
            cun += sum/100;
            sum %= 100;
            if (sum<0)
                break;
        }
        if (sum<0)
            printf("-%d\n",i+1);
        else
            printf("%d\n",cun*120+sum);
    }
}        