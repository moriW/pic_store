 
//
//  main.cpp
//  组合数
//
//  Created by Moridisa on 14-9-4.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <cmath>
#include <cstdio>
using namespace std;

bool juge(int num)
{
    int temp;
    while (num) {
        temp = num%10;
        num/=10;
        if (num==0)
            break;
        if (temp>=num%10)
            return false;
    }
    return true;
}


int main()
{
    
    int n,m;
    while (cin>>n>>m) {
        
        int sum = 0;
        for (int i = m, j = n; i != 0 ; i--,j--)
            sum += j*pow(10, i-1);
//        if (m==n) {
//            printf("%d\n",sum);
//            continue;
//        }
//        if (m==1) {
//            for (int i = n; i!=0; i--)
//                printf("%d\n",i);
//            continue;
//        }
        while (sum>pow(10, m-1)) {
            if (sum%10 && juge(sum))
                printf("%d\n",sum);
            sum--;
        }
    }
    
}        