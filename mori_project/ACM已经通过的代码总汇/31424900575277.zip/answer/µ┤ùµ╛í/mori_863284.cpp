 
#include <stdio.h>
#include <iostream>
using namespace std;

//NYOJ506

bool juge(int a)
{
    while (a) {
        if (a%10==4)
            return true;
        a/=10;
    }
    return false;
}

int main()
{
    int a[50001]={0};
    for (int i=1; i<50000; i++) {
        if (juge(i))
            a[i]=a[i-1];
        else
            a[i]=a[i-1]+1;
        //printf("%d ",a[i]);
    }int n;
    while (scanf("%d",&n)!=EOF) {
        printf("%d\n",a[n]);
    }
    
}        