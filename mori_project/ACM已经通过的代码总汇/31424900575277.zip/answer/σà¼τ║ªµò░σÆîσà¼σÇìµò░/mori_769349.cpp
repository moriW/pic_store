 
//
//  main.c
//  公约数和公倍数
//
//  Created by Moridisa on 14-3-18.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int loop,a,b,t;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d%d",&a,&b);
        t=a*b;
        if (a==b) {
            printf("%d %d\n",a,b);
        }else{
            int n=1;
            while (b!=0) {
                n=a%b;
                a=b;
                b=n;
            }printf("%d %d\n",a,t/a);
        }
    }
}
        