 
#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
    int loop;
    cin >> loop;
    while (loop--) {
        int n,t,a[100002]={0},k,max=0;
        cin >> n;
        for (int i=0; i<n; i++) {
            cin >> k;
            a[k]++;
        }for (int i=0; i<100002; i++) {
            if (a[i]!=0) {
                if (a[i]>max) {
                    max=a[i];
                    t=i;
                }
            }
        }printf("%d %d\n",t,max);
    }
}        