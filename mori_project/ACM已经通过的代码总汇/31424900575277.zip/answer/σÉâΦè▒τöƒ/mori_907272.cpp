 
#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
int main()
{
int T;
scanf("%d",&T);
while(T--)
{
int i,a[8];
char st[20];
for(i=0;i<7;i++)
scanf("%d",&a[i]);
sort(a,a+7);
scanf("%s",st);
if(st[0]=='M'&&st[1]=='o')
printf("%d\n",a[0]);
if(st[0]=='T'&&st[1]=='u')
printf("%d\n",a[1]);
if(st[0]=='W'&&st[1]=='e')
printf("%d\n",a[2]);
if(st[0]=='T'&&st[1]=='h')
printf("%d\n",a[3]);
if(st[0]=='F'&&st[1]=='r')
printf("%d\n",a[4]);
if(st[0]=='S'&&st[1]=='a')
printf("%d\n",a[5]);
if(st[0]=='S'&&st[1]=='u')
printf("%d\n",a[6]); 
}
return 0;
}        