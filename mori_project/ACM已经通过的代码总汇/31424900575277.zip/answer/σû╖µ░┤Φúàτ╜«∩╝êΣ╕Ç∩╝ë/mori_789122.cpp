 
//
//  main.c
//  喷水装置
//
//  Created by Moridisa on 14-3-30.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <math.h>
void mp(float s[],int n)
{
    for (int i=0; i<n; i++) {
        for (int j=i+1; j<n; j++) {
            if (s[i]>s[j]) {
                s[i]+=s[j];
                s[j]=s[i]-s[j];
                s[i]-=s[j];
            }
        }
    }
}

float cd(int ri)
{
    return sqrtf(ri*ri-4);
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n,time=0;
        scanf("%d",&n);
        float ri[n],l=0;
        int biger=n-1;
        for (int i=0; i<n; i++) {
            scanf("%f",&ri[i]);
        }mp(ri, n);
        while (l<20) {
            l+=cd(2*ri[biger]);
            biger--;
            time++;
        }printf("%d\n",time);
    }
}        