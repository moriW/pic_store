 
#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <cstdio>
//from coder mori
using namespace std;

int main()
{
    int n,t;
    //freopen("c.txt","r",stdin);
    cin>>n;
    while(n--){
        cin>>t;
        for(int i=t;i>=1;i--){
            for(int j=0;j<i;j++)
                cout<<'*';
            cout<<endl;
        }
    }
}
        