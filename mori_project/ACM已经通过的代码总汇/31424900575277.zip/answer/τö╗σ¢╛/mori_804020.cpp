 
//
//  main.c
//  a letter and a number
//
//  Created by Moridisa on 14-4-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    for (int i=0; i<n; i++) {
        for (int j=0; j<n; j++) {
            printf("*");
        }printf("\n");
    }
}        