 
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int loop,a[10],b;
    cin>>loop;
    while (loop--) {
        int sum = 0;
        for (int i = 0; i<10; i++)
            cin>>a[i];
        cin>>b;
        b+=30;
        sort(a, a+10);
        for (int i = 0; a[i]<=b; i++)
            sum++;
        cout<<sum<<endl;
    }
}        