 
//
//  main.c
//  小学生算数
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
int main()
{
    int m,n=1,a[3],b[3];
    while (m!=0&&b!=0) {
        scanf("%d%d",&m,&n);
        int time=0;
        a[2]=m/100;
        b[2]=n/100;
        a[1]=m/10-a[2]*10;
        b[1]=n/10-b[2]*10;
        a[0]=m-a[2]*100-a[1]*10;
        b[0]=n-b[2]*100-b[1]*10;
        for (int i=0; i<3; i++) {
            if (a[i]+b[i]>9) {
                time++;
                a[i+1]++;
            }
        }if (m==0&&n==0) {
            break;
        }else{printf("%d\n",time);}
    }
}        