 
//
//  main.cpp
//  士兵杀敌（一）
//
//  Created by Moridisa on 14-6-9.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
int main()
{
    int n,m,x,y;
    long long a[1000010]={0};
    scanf("%d%d",&n,&m);
    for (int i=1; i<=n; i++) {
        scanf("%lld",&a[i]);
        a[i]+=a[i-1];
    }
    for (int i=0; i<m; i++) {
        scanf("%d%d",&x,&y);
        //printf("%lld %lld\n",a[y],a[x-1]);
        printf("%lld\n",a[y]-a[x-1]);
    }
}        