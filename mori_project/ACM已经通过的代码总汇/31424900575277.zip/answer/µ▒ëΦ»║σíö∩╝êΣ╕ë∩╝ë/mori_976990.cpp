 
//
//  main.cpp
//  汉诺塔(三)数组
//
//  Created by Mori.William on 14-9-18.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;

int main()
{
    int loop,m,n,a,b;
    bool temp,end;
    cin>>loop;
    while (loop--) {
        cin>>n>>m;
        stack<int> p[3];
        for (int i = n; i!=0; i--)
            p[0].push(i);
        temp = true,end = true;
        
        while (m--) {
            cin>>a>>b;
            a--;
            b--;
            if (p[a].size() == 0 || (p[b].size()!=0 && p[a].top() > p[b].top() ))
                temp = false;
            else{
                p[b].push(p[a].top());
                p[a].pop();
            }
            end = end==false ? false:temp;
        }
        if (end)
            cout<<"legal"<<endl;
        else
            cout<<"illegal"<<endl;
    }
}        