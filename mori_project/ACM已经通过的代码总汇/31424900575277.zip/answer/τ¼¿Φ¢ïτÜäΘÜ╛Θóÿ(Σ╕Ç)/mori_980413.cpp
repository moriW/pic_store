 
//
//  main.cpp
//  笨蛋的难题(一)
//
//  Created by Mori.William on 14-9-23.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//
//West 西
//East 东
//North 北
//South 南

#include <cstdio>
#include <cstring>
void turnLeft(char *f)
{
    if (*f=='N')
        strcpy(f,"West");
    else if (*f == 'E')
        strcpy(f, "North");
    else if (*f == 'S')
        strcpy(f, "East");
    else
        strcpy(f, "South");
}

void turnRight(char *f)
{
    if (*f=='N')
        strcpy(f,"East");
    else if (*f == 'E')
        strcpy(f, "South");
    else if (*f == 'S')
        strcpy(f, "West");
    else
        strcpy(f, "North");
}

void turn(char *f,int left_right)
{
    if (left_right)
        turnRight(f);
    else
        turnLeft(f);
}

int main()
{
    char faceTo[5];
    int time,temp;
    while (~scanf("%s%d",faceTo,&time)) {
        while (time--) {
            scanf("%d",&temp);
            turn(faceTo, temp);
        }
        printf("%s\n",faceTo);
    }
}        