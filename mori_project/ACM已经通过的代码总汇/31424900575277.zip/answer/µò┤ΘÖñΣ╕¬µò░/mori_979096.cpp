 
//
//  main.cpp
//  整除个数
//
//  Created by Mori.William on 14-9-21.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>

int main()
{
    int a,b;
    while (~scanf("%d%d",&a,&b)) {
        for (int i = a; i<=b; i++)
            if (i%3==0)
                printf("%d ",i);
        printf("\n");
    }
}        