 
#include <cstdio>
#include <algorithm>
using namespace std;
int main()
{
    int a[50],b[3],n,max_value,max_biaohao,sum;
    while(scanf("%d",&n)!=EOF){
        for(int i = 0;i<n;i++)
            scanf("%d",&a[i]);
        max_value = 0;sum = 0;
        for(int i = 2;i!=-1;i--){
            for(int j = 0;j!=n;j++){
                if(a[j]>max_value){
                    max_value = a[j];
                    max_biaohao = j;
                }
            }
            sum += max_value;
            b[i] = max_biaohao+1;
            a[max_biaohao] = 0;
            max_value = 0;
        }
        sort(b,b+3);
        printf("%d %d %d %d\n",b[0],b[1],b[2],sum);
    }
}
        