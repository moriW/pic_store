 
#include <stdio.h>

int main()
{
    int lo;
    scanf("%d\n",&lo);
    while (lo--) {
        int a[26]={0},max=0;
        char s[1011];
        for (int i=0;(s[i]=getchar())!='\n'; i++) {
            a[(int)s[i]-97]++;
        }for (int i=0; i<26; i++) {
            if (a[max]<a[i]) {
                max=i;
            }
        }printf("%c\n",max+97);
    }
}
        