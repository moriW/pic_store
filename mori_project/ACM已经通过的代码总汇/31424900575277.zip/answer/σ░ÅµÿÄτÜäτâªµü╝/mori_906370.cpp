 
//
//  main.cpp
//  小明的烦恼
//
//  Created by Moridisa on 14-6-30.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <string>
#include <cmath>
#define ppow(a,b) a*pow(10,b)
using namespace std;

int main()
{
    int loop;
    cin>>loop;
    while (loop--) {
        char a[11];
        long long sum=0,t=0;
        cin>>a;
        //cout<<a[0]<<a[10]<<endl;
        for (int i=11; i>=0; i--) {
            //cout<<a[i]<<' ';
            if (a[i]<97||a[i]>122)
                continue;
            if (a[i]>=97&&a[i]<=99)
                sum+=ppow(2, t);
            if (a[i]>=100&&a[i]<=102)
                sum+=ppow(3, t);
            if (a[i]>=103&&a[i]<=105)
                sum+=ppow(4, t);
            if (a[i]>=106&&a[i]<=108)
                sum+=ppow(5, t);
            if (a[i]>=109&&a[i]<=111)
                sum+=ppow(6, t);
            if (a[i]>=112&&a[i]<=115)
                sum+=ppow(7, t);
            if (a[i]>=116&&a[i]<=118)
                sum+=ppow(8, t);
            if (a[i]>=119&&a[i]<=122)
                sum+=ppow(9, t);
            //cout<<sum<<" t="<<t<<endl;
            t++;
        }
        cout<<sum<<endl;
    }
}        