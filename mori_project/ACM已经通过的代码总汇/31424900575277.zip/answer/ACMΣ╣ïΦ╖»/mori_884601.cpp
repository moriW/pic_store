 
#include <iostream>
using namespace std;

int main()
{
    int n;
    cin>>n;
    while(n--)
         cout<<"I Love Acm."<<endl;
}        