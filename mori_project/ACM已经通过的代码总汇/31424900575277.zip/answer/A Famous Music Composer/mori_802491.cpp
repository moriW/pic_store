 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    int i,d=1,flag;
    char a[1000];
    while(gets(a))
    {
        flag=0;
        printf("Case %d: ",d);
        d++;
        if(a[0]=='A'&&a[1]=='b') { a[0]='G'; a[1]='#';}
        else if(a[0]=='A'&&a[1]=='#') { a[0]='B'; a[1]='b';}
        else if(a[0]=='B'&&a[1]=='b') { a[0]='A'; a[1]='#';}
        else if(a[0]=='C'&&a[1]=='#') { a[0]='D'; a[1]='b';}
        else if(a[0]=='D'&&a[1]=='b') { a[0]='C'; a[1]='#';}
        else if(a[0]=='D'&&a[1]=='#') { a[0]='E'; a[1]='b';}
        else if(a[0]=='E'&&a[1]=='b') { a[0]='D'; a[1]='#';}
        else if(a[0]=='G'&&a[1]=='b') { a[0]='F'; a[1]='#';}
        else if(a[0]=='F'&&a[1]=='#') { a[0]='G'; a[1]='b';}
        else if(a[0]=='G'&&a[1]=='#') { a[0]='A'; a[1]='b';}
        else if(a[0]=='A'&&a[1]=='b') { a[0]='G'; a[1]='#';}
        else flag=1;
        
        if(flag==0) printf("%s\n",a);
        else printf("UNIQUE\n");
    }
}        