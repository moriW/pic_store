 
#include <iostream>
#include <cstring>
#define max(a,b) a>=b? a:b
using namespace std;

int dp[1003][1003];
int main()
{
    int loop,i,j;
    int lenOfStr1,lenOfStr2;
    char str1[1003],str2[1003];
    cin>>loop;
    while(loop--){
        memset( dp , 0 , sizeof(dp) );
        cin>>str1>>str2;
        lenOfStr1 = (int)strlen(str1);
        lenOfStr2 = (int)strlen(str2);
        for( i = 1 ; i <= lenOfStr1 ; i++ ){
            for( j = 1 ; j <= lenOfStr2 ; j++ ){
                if( str1[i-1] == str2[j-1] )
                    dp[i][j] = dp[i-1][j-1] + 1;
                else
                    dp[i][j] = max(dp[i-1][j],dp[i][j-1]);
            }
        }

        cout<<dp[lenOfStr1][lenOfStr2]<<endl;
    }
}
        