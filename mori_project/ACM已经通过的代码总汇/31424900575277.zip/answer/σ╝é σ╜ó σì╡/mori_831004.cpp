 
//
//  main.c
//  异形卵
//
//  Created by Moridisa on 14-4-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>


int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int l,n,a[1005]={0},sum[1005]={-1};
        scanf("%d%d",&l,&n);
        int m=l-1,k=0;
        for (int i=1; i<=n; i++) {
            scanf("%d",&a[i]);
        }
        for (int i=1; i+m<=n; i++) {
            for (int j=i; j<=i+m; j++) {
                sum[i]+=a[j];
            }
            if (sum[i]>sum[k]) {
                k=i;
            }
        }
        printf("%d\n",k);
    }
}        