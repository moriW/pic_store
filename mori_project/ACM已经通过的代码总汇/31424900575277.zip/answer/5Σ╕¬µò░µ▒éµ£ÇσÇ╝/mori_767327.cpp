 
//
//  main.c
//  三个数从小到大排序
//
//  Created by Moridisa on 14-3-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int a,b,c,d,e,t;
    scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
    if (a>b) {
        t=b;
        b=a;
        a=t;
    }if (a>c) {
        t=b;
        b=a;
        a=t;
    }if (a>d) {
        t=d;
        d=a;
        a=t;
    }if (a>e) {
        t=e;
        e=a;
        a=t;
    }if (b>c) {
        t=c;
        c=b;
        b=t;
    }if (b>d) {
        t=d;
        d=b;
        b=t;
    }if (b>e) {
        t=e;
        e=d;
        d=t;
    }if (c>d) {
        t=d;
        d=c;
        c=t;
    }if (c>e) {
        t=e;
        e=c;
        c=t;
    }if (d>e) {
        t=e;
        e=d;
        d=t;
    }
    printf("%d %d\n",a,e);
}        