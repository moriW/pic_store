 
//
//  main.cpp
//  不高兴的小明
//
//  Created by Moridisa on 14-5-6.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int a[8]={0},b,c,t=7,k=7;
        for (int i=0; i<7; i++) {
            scanf("%d %d",&b,&c);
            a[i]=b+c;
        }
        while (t--) {
            if (a[t]>8&&a[t]>=a[k])
                k=t;
        }
        printf("%d\n",k==7?0:k+1);
    }
}        