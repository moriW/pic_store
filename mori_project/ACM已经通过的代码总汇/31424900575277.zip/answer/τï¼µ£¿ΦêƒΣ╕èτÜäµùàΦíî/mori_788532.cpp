 
#include <stdio.h>
int main(){
    int n,m,a[305]={0},w,i,j,head,end,tmp,sum;
    scanf("%d",&n);
    while(n--){
        scanf("%d %d",&w,&m);
        for(i=0;i<m;i++)
            scanf("%d",&a[i]);
        for(i=0;i<m;i++){
            head=i;
            for(j=i+1;j<m;j++){
                if(a[j]>a[head])
                    head=j;
            }
            tmp=a[i];
            a[i]=a[head];
            a[head]=tmp;
        }
        head=0,end=m-1,sum=0;
        while(head<=end){
            if(head==end){
                sum++;
                break;
            }
            else if(a[head]+a[end]<=w){
                sum++;
                head++,end--;
            }
            else if(a[head]+a[end]>w){
                sum+=1;
                head++;
            }
        }
        printf("%d\n",sum);
        for(i=0;a[i]!=0;i++)
            a[i]=0;
    }
    return 0;
}        