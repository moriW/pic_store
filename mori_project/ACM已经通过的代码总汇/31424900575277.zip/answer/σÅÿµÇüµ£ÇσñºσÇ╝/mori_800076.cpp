 
#include <stdio.h>

int most(int a[],int juge)
{
    for (int i=0; i<3; i++) {
        for (int j=i+1; j<3; j++) {
            if (a[i]>a[j]) {
                a[i]+=a[j];
                a[j]=a[i]-a[j];
                a[i]-=a[j];
            }
        }
    }if (juge==0) {
        return a[0];
    }else{
        return a[2];
    }
}

int main()
{
    int n;
    while (scanf("%d",&n)!=EOF) {
        int a[3],b=0,c;
        for (int i=1; i<=n/3; i++) {
            for (int j=0; j<3; j++) {
                scanf("%d",&a[j]);
            }
            c=most(a, i%2);
            b=b>c?b:c;
        }printf("%d\n",b);
    }
}        