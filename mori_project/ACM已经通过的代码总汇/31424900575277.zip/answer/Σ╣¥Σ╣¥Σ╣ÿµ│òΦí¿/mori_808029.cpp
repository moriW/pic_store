 
#include <stdio.h>

void    chengFaBiao(int n)
{
    int cheng=1,bCheng=1,out;
    for (cheng=1; cheng<=n; cheng++) {
        for (bCheng=cheng; bCheng<=9; bCheng++) {
            out=cheng*bCheng;
            printf("%d*%d=%d ",cheng,bCheng,out);
        }printf("\n");
    }
}

int main()
{
    int n,a;
    scanf("%d",&n);
    while (n--) {
        scanf("%d",&a);
        chengFaBiao(a);
    }
}        