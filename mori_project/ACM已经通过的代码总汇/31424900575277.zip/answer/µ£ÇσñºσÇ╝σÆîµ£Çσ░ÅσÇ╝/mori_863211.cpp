 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char a[103];
int cmp(const void *a,const void *b)
{
    return *(char *)a-*(char *)b;
}
int main()
{
    int s;
    scanf("%d",&s);
    while(s--)
    {
        int i,n,t;
        scanf("%s",a);
        n=strlen(a);
        qsort(a,n,sizeof(a[0]),cmp);
        for(i=0;i<n;i++)
            if(a[i]!='0') break;
        t=i;
        if(t==n) printf("0 0\n");
        else
        {
            for(i=n-1;i>=0;i--)
                printf("%c",a[i]);
            printf(" ");
            for(i=t;i<n;i++)
                printf("%c",a[i]);
            printf("\n");
        }
    }
    return 0;
}        