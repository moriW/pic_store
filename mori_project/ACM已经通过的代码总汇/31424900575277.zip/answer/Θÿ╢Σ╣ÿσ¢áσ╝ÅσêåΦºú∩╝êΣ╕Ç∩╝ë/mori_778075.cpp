 
//
//  main.c
//  阶乘因式分解
//
//  Created by Moridisa on 14-3-18.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
int main()
{
    int loop,m,n;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d%d",&m,&n);
        long int sum=0;
        while (1) {
            sum+=m/n;
            m=m/n;
            if (m==0) {
                break;
            }
        }printf("%ld\n",sum);
    }
}        