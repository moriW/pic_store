 
#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int H,days=0,hei=0;
        scanf("%d",&H);
        for (int i=0; 1; i++) {
            days++;
            hei+=10;
            if (hei>=H) {
                break;
            }hei-=5;
        }printf("%d\n",days);
    }
}        