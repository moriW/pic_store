 
//
//  main.c
//  6174问题
//
//  Created by Moridisa on 14-3-19.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int nu(int k)
{
    int t[4],a,b;
    t[0]=k/1000;
    t[1]=k/100-t[0]*10;
    t[2]=k/10-t[0]*100-t[1]*10;
    t[3]=k-t[0]*1000-t[1]*100-t[2]*10;
    for (int i=0; i<4; i++) {
        for (int j=0; j<3-i; j++) {
            if (t[j]>t[j+1]) {
                a=t[j+1];
                t[j+1]=t[j];
                t[j]=a;
            }
        }
    }a=t[0]*1000+t[1]*100+t[2]*10+t[3];
    b=t[3]*1000+t[2]*100+t[1]*10+t[0];
    return b-a;
}

int main()
{
    int a,b,loop,i=1;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&a);
        while(i++){
            b=nu(a);
            a=b;
            
            if (a==6174&&b==6174) {
                printf("%d\n",i);
                i=1;
                break;
            }
        }
    }
}        