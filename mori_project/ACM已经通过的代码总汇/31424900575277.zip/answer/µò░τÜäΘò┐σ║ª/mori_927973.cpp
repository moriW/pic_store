 
#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

int main()
{
    int loop,t;
    long long result;
    cin>>loop;
    while (loop--) {
        cin>>t;
        if (t==1)
            cout<<1<<endl;
        else{
            result=(long)((log10(sqrt(4.0*acos(0.0)*t))+t*(log10(t)-log10(exp(1.0))))+1);
            cout<<result<<endl;
        }
    }
    return 0;
}        