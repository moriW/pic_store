 
#include <cstdio>
#include <cstring>
#define max(a,b) a>b?a:b

int main()
{
    int loop,c,w,n,v;
    int dp[50005];
    scanf("%d",&loop);
    while(loop--){
        memset( dp , -10000 , sizeof(dp) );
        dp[0] = 0;
        scanf("%d%d",&n,&v);
        for( int i = 0 ; i != n ; i++ ){
            scanf("%d%d",&c,&w);
            for( int j = c ; j <= v ; j++ )
                dp[j] = max(dp[j],dp[j-c]+w);
        }
        if(dp[v]<0)
            printf("NO\n");
        else
            printf("%d\n",dp[v]);
    }
}
        