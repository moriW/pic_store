 
// A problem is easy.cpp : 定义控制台应用程序的入口点。
//

#include "stdio.h"
#include "math.h"

int main()
{
	int loop;
	scanf("%d",&loop);
	while(loop--){
		int a,b,time=0;
		scanf("%d",&a);
		b=(int)sqrt((double)a+1);
		for(int i=2;i<=b;i++){
			if((a+1)%i==0)
				time++;
		}printf("%d\n",time);
	}

}        