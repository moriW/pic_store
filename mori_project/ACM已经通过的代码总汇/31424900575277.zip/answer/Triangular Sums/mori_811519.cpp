 
#include <stdio.h>

int main()
{
    int loop,t=1;
    scanf("%d",&loop);
    while (loop--) {
        int n,sum=0;
        scanf("%d",&n);
        for (int i=1; i<=n; i++) {
            sum+=(i*i+3*i+2)*i/2;
        }printf("%d %d %d\n",t,n,sum);
        t++;
    }
}        