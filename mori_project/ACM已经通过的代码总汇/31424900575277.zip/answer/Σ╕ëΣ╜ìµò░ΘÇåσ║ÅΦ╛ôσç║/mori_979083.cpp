 
//
//  main.cpp
//  三位数逆序输出
//
//  Created by Mori.William on 14-9-21.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    char a[3];
    while (cin>>a) {
        for (int i = 2; i!=-1; i--)
            cout<<a[i];
        cout<<endl;
    }
}        