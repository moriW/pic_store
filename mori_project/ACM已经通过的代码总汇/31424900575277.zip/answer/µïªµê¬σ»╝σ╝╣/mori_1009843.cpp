 
//
//  main.cpp
//  拦截导弹
//
//  Created by Mori.William on 14/10/18.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;

int main()
{
    int loop,ans;
    int n,height[22],dp[22];
    cin>>loop;
    while (loop--) {
        cin>>n;
        ans = 0;
        for (int i = 0; i<n; i++)
            cin>>height[i];
        
        for (int i = n-1; i!=-1; i--) {
            dp[i] = 1;
            for (int j = n-1; j>i ; j--){
                if (height[j]<height[i])
                    dp[i] = max(dp[i], dp[j]+1);
            }
            ans = max(ans, dp[i]);
        }
        cout<<ans<<endl;
    }
}        