 
//
//  main.cpp
//  万圣节
//
//  Created by Moridisa on 14-4-27.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#include <math.h>

void Jinwei(char a[])
{
    a[5]++;
    for (int i=5; i>=0; i--) {
        if (a[i]>'6') {
            a[i]='0';
            a[i-1]++;
        }
    }
}

bool Juge(char a[])
{
    if (strstr(a,  "05")) return false;
    if (strstr(a,  "06")) return false;
    if (strstr(a,  "50")) return false;
    if (strstr(a,  "16")) return false;
    if (strstr(a,  "50")) return false;
    if (strstr(a,  "60")) return false;
    if (strstr(a,  "61")) return false;
    if (strstr(a, "000")) return false;
    if (strstr(a, "111")) return false;
    if (strstr(a, "222")) return false;
    if (strstr(a, "333")) return false;
    if (strstr(a, "444")) return false;
    if (strstr(a, "555")) return false;
    if (strstr(a, "666")) return false;
    return true;
}

int chToin(char a[])
{
    int b=0;
    for (int i=0; i<6; i++) {
        b+=(a[i]-48)*(int)pow(10, 5-i);
    }return b;
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        char a[7],b[7],c[7];
        scanf("%s%s",a,b);
        strcpy(c, a);
        for (c; strcmp(b, c)!=0;) {
            if (Juge(c))
                printf("%s\n",c);
            Jinwei(c);
        }if (Juge(b)) {
            printf("%s\n",b);
        }
        printf("\n");
    }
}        