 
//
//  main.cpp
//  最大公约数
//
//  Created by Mori.William on 14-9-21.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>

int gcd(int a,int b){ return b == 0 ? a:gcd(b, a%b);}

int main()
{
    int a,b;
    while (~scanf("%d,%d",&a,&b)) {
        printf("%d\n",gcd(a, b));
    }
}        