 
//
//  main.c
//  不信邪试试
//
//  Created by mori on 14-1-16.
//  Copyright (c) 2014年 mori. All rights reserved.
//
#include <stdio.h>
#include <string.h>


int count(char s[80])
{
    int i=0,x=0,sum=0;;
    while (s[i]!='\0') {
        if (s[i]=='0') {
            x=0;
        }
        if (s[i]=='1') {
            x=1;
        }
        if (s[i]=='2') {
            x=2;
        }
        if (s[i]=='3') {
            x=3;
        }
        if (s[i]=='4') {
            x=4;
        }
        if (s[i]=='5') {
            x=5;
        }
        if (s[i]=='6') {
            x=6;
        }
        if (s[i]=='7') {
            x=7;
        }
        if (s[i]=='8') {
            x=8;
        }
        if (s[i]=='9') {
            x=9;
        }
        sum+=x;
        i++;
    }
    return sum;
}

int main()
{
    char a[40],b[40],c;
    int t;
    scanf("%d",&t);
    while (t>0) {
        scanf("%s%c%s",a,&c,b);
        printf("%d\n",count(a)*count(b));
        t--;
    }
}        