 
//
//  main.cpp
//  会场安排问题
//
//  Created by Moridisa on 14-5-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//
#include <iostream>
#include <stdlib.h>
#include <algorithm>
#include <cstdio>
using namespace std;

struct time
{
    int s,e;
};

bool cmp(struct time x,struct time y)
{
    if (x.e==y.e)
        return x.s>y.s;
    return x.e<y.e;
}

int main()
{
    int loop,n;
    cin>>loop;
    while (loop--) {
        cin>>n;
        int count = 1,g;
        struct time *a = new struct time[n];
        for (int i=0; i<n; i++)
            scanf("%d%d",&a[i].s,&a[i].e);
        sort(a, a+n, cmp);
        //for (int i=0; i<n; i++)
            //cout<<a[i].s<<' '<<a[i].e<<endl;
        g=a[0].e;
        for (int i=1; i<n; i++) {
            if (a[i].s>=g+1) {
                //cout<<a[i].s<<' '<<a[i].e<<endl;
                g=a[i].e;
                count++;
            }
        }
        cout<<count<<endl;
    }
    return 0;
}        