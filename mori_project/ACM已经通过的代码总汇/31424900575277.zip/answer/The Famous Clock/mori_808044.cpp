 
#include<stdio.h>
#include<string.h>
int main()
{
    char ss[12][10]={"I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"};
    char s[10];
    int j=1;
    while(scanf("%s",s)!=EOF){
        
        for(int i=0;i<12;i++)
            if(strcmp(s,ss[i])==0){
                printf("Case %d: %d\n",j++,i+1);
                break;
            }
        
    }
    return 0;
}        