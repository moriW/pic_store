 
#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        char s[201];
        int t=0;
        getchar();
        scanf("%s",s);
        for (int i=0; s[i]!='\0'; i++) {
            if (s[i]>=97&&s[i]<=122) {
                t++;
            }
        }t%=26;
        if (t==0) {
            printf("z\n");
        }else{
            printf("%c\n",t+96);
        }
    }
}        