 
//
//  main.cpp
//  小明的调查统计(二)
//
//  Created by Mori.William on 14-9-20.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

struct student{
    int _score;
    int _class;
    int _num;
    int _mingci;
};

bool compare(student a,student b)
{
    if (a._score==b._score){
        if (a._class==b._class)
            return a._num < b._num;
        return a._class < b._class;
    }
    return a._score > b._score;
}

int main()
{
    int n,m,rs,t;
    student a[100002];
    while (cin>>n>>m) {
        t = 0;
        for (int i = 1; i<=n; i++) {
            scanf("%d",&rs);
            for (int j = 1; j<=rs; j++) {
                scanf("%d",&a[t]._score);
                a[t]._class = i;
                a[t]._num = j;
                t++;
            }
        }
        sort(a, a+t, compare);
        rs = 1;
        for (int i = 0; i<t; i++) {
            a[i]._mingci =  rs;
            if (a[i]._score != a[i+1]._score)
                rs++;
        }
        
        while (m--) {
            scanf("%d",&rs);
            for (int i =  0; i<t; i++)
                if (a[i]._mingci == rs)
                    printf("%d %d\n",a[i]._class,a[i]._num);
        }
        
    }
}        