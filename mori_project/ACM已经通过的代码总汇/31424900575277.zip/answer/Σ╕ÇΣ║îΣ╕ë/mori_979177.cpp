 
//
//  main.cpp
//  一二三
//
//  Created by Mori.William on 14-9-21.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>
#include <cstring>
using namespace std;

int juge(char *a)
{
    int sum = 0;
    char one[] = "one";
    if (strlen(a)==5)
        return 3;
    else{
        int i = 0;
        while (a[i]!='\0') {
            if (a[i] == one[i])
                sum++;
            i++;
        }
    }
    return sum>=2? 1:2;
}

int main()
{
    int loop;
    char temp[6];
    scanf("%d",&loop);
    while (loop--) {
        scanf("%s",temp);
        printf("%d\n",juge(temp));
    }
}        