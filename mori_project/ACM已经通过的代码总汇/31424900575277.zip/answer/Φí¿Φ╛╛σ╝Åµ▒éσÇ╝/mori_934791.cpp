 
#include<stdio.h>
#include<stack>
#include<string.h>
using namespace std;
stack<char> point;
stack<int> num;
int min(int a, int b){
if(a > b)
return b;
else
return a;
}
int max(int a, int b){
if(a > b)
return a;
else
return b;
}
int add(int a, int b){
return a + b;
}
int main(){
int i, n, a, b, chiose;
scanf("%d", &chiose);
char str[301000], c;
while(chiose--){
scanf("%s", str);
n = strlen(str);
for(i = 0; i < n; i++){
if(str[i] == 'd' && str[i + 1] == 'd'){
point.push(str[i]);
i++;
}
if(str[i] == 'n' || str[i] == 'x')
point.push(str[i]);
if(str[i] <= '9' && str[i] >= '0'){
a = 0;
while(str[i] != ',' && str[i] != ')' && i < n){
a = a * 10 + str[i] - '0';
i++;
}
num.push(a);
}
if(str[i] == ')'){
a = num.top();
num.pop();
b = num.top();
num.pop();
c = point.top();
point.pop();
if(c == 'd')
num.push(add(a, b));
if(c == 'n')
num.push(min(a, b));
if(c == 'x')
num.push(max(a, b));
}
}
printf("%d\n", num.top());
num.pop();
}
return 0;
}        