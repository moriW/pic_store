 
//
//  main.c
//  1的个数
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
int main()
{
    int loop,num,x,y,tim=0;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&num);
        tim=0;
        while (num) {
            x=num/2;
            y=num%2;
            if (y==1) {
                tim++;
            }
            num=x;
        }printf("%d\n",tim);
    }
}        