 
//
//  main.cpp
//  coin test
//
//  Created by Moridisa on 14-4-28.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <math.h>
int gcd(int a,int b)//阿基里德算法
{
    return b==0?a:gcd(b, a%b);
}

int Juge(char a[])//判断
{
    int sum=0;
    for (int i=0; a[i]!='\0'; i++) {
        sum+=a[i]=='U'?1:0;//计数器：U的数量
        if (a[i]=='S')//如果有S，返还-1 因为有可能会有0的U面，全部为D面
            return -1;
    }return sum;
}

int main()
{
    double n,m,j;
    while (scanf("%lf",&n)!=EOF) {
        char a[65540];
        scanf("%s",a);
        m=Juge(a);//得到u的数量，或者-1
        j=m/n-0.5;
        if (m==-1){
            printf("Bingo\n");
            continue;
        }if (m&&((j>=0&&j<=0.003)||(j<=0&&j>=-0.003))) {
            printf("%.0lf/%.0lf\n",m/gcd(n, m),n/gcd(n, m));
            continue;
        }printf("Fail\n");
    }
}        