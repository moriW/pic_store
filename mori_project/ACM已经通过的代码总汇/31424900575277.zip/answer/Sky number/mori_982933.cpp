 
#include <cstdio>

int jinzhi(int a,int b)
{
    int sum = 0;
    while(a){
        sum += a%b;
        a /= b;
    }
    return sum;
}

int main()
{
    int n;
    while(scanf("%d",&n),n!=0){
        if( jinzhi(n,10)==jinzhi(n,12) && jinzhi(n,16)==jinzhi(n,12) )
            printf("%d is a Sky Number.\n",n);
        else
            printf("%d is not a Sky Number.\n",n);
    }
}
        