 
//
//  main.cpp
//  小珂的游戏
//
//  Created by mori on 14-9-12.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

//
//#include <iostream>
//using namespace std;
//
//struct node{
//    int data;
//    node *next;
//};
//
//void copyLian(node *a,node *b)
//{
//    node * temp = a;
//    node *k = b;
//    for (temp; temp->next != a; temp = temp->next) {
//        b->data = temp->data;
//        b->next = (node *)malloc(sizeof(node));
//        b = b->next;
//    }
//    b->data = temp->data;
//    b->next = k;
//}
//
//node *dele(node *t)
//{
//    node *temp = t;
//    for (temp; temp->next!=t; temp = temp->next);
//    temp->next = t->next;
//    delete t;
//    return temp->next;
//}
//
//int juge(node *t,int n,int time)
//{
//    
//    node *temp = new node;
//    copyLian(t, temp);
//    int k = n*2;
//    for (int i = 0; i!=n; i++) {
//        int j = 1;
//        while (j + k < time)
//            j += k;
//        
//        for (j; j!=time; j++)
//            temp = temp->next;
//        
//        if (temp->data <= n)
//            return 0;
//        else{
//            temp = dele(temp);
//            k--;
//        }
//    }
//    return time;
//}
//
//int main()
//{
//    int n;
//    while (cin>>n) {
//        
//        //绘制环链
//        node *a = (node *)malloc(sizeof(node));
//        node *lian = a;
//        for (int i = 1; i != 2*n; i++) {
//            a->data = i;
//            a->next = (node *)malloc(sizeof(node));
//            a = a->next;
//        }
//        a->data = 2*n;
//        a->next = lian;
//        a = lian;
//        //输出环链
//        for (int i = 0; i != 2*n; i++){
//            cout<<a->data<<' ';
//            a = a->next;
//        }
//        cout<<endl;
//        
//        //测试复制链表 让复制出来的链表与 原链表独立(地址不重复)
//        node *k = new node;
//        copyLian(a, k);
//        for (int i = 0; i!=2*n; i++) {
//            cout<<k->data<<' ';
//            k = k->next;
//        }
//        
//        for (int i = n+1; ;i++) {
//            int temp = juge(a, n, i);
//            if (temp) {
//                cout<<temp<<endl;
//                break;
//            }
//        }
//        
//    }
//    return 0;
//}
////结果在此
//2
//7
//5
//30
//169
//441
//1872
//7632
//1740
//93313
//459901
//1358657
//2504881


#include <iostream>
using namespace std;
int main()
{
    int a[15]={2,7,5,30,169,441,1872,7632,1740,93313,459901,1358657,2504881,13482720,25779600},n;
    while (cin>>n,n!=0) {
        cout<<a[n-1]<<endl;
    }
}
        