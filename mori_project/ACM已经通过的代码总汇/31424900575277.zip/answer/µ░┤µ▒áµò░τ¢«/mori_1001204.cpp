 
//
//  main.cpp
//  水池数目
//
//  Created by Mori.William on 14-10-10.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>

int a[100][100],xMax,yMax;

void dfs(int x,int y)
{
    a[y][x] = 0;
    
    for (int xx = -1; xx!=2; xx++)
        if ( 0<=xx+x && xx+x<xMax && a[y][x+xx])
            dfs(xx+x, y);
    
    for (int yy = -1; yy!=2; yy++)
        if ( 0<=yy+y && yy+y<yMax && a[yy+y][x])
            dfs(x, yy+y);
    
    return ;
}

int main()
{
    
    int loop,sum;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d%d",&yMax,&xMax);
        sum = 0;
        
        for (int y = 0; y!=yMax; y++)
            for (int x = 0; x!=xMax; x++)
                scanf("%d",&a[y][x]);
        
        for (int y = 0; y != yMax; y++) {
            for (int x = 0; x != xMax; x++) {
                if (a[y][x]) {
                    dfs(x, y);
//                    
//                    printf("\n\n");
//                    for (int y = 0; y!=yMax; y++) {
//                        for (int x = 0; x!=xMax; x++) {
//                            printf("%d ",a[y][x]);
//                        }
//                        printf("\n");
//                    }
//                    printf("\n\n");
                    sum ++;
                }
            }
        }
        
        printf("%d\n",sum);
        
    }
    
    return 0;
}        