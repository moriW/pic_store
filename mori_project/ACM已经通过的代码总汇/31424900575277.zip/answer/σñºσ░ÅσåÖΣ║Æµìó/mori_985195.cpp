 
//
//  main.cpp
//  大小写互换
//
//  Created by Mori.William on 14-10-1.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>
#include <cstring>

int main()
{
    char a[102];
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%s",a);
        for(int i = 0;i!=strlen(a);i++){
            if (a[i] >= 'a' && a[i] <= 'z')
                a[i] -= 32;
            else if (a[i] >= 'A' && a[i] <= 'Z' )
                a[i] += 32;
        }
        printf("%s\n",a);
    }
}        