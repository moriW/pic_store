 
#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        char s[101];
        scanf("%s",s);
        for (int i=0; s[i]!='\0'; i++) {
            printf("%c",s[i]>=90?s[i]-32:s[i]+32);
        }printf("\n");
    }
}        