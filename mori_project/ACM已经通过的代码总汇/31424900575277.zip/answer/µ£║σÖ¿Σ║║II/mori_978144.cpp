 
//
//  main.cpp
//  机器人II
//
//  Created by Mori.William on 14-9-20.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

void turnLeft(char *a)
{
    switch (*a) {
        case 'N':*a = 'W';break;
        case 'W':*a = 'S';break;
        case 'S':*a = 'E';break;
        case 'E':*a = 'N';break;
    }
}

void turnRight(char *a)
{
    switch (*a) {
        case 'N':*a = 'E';break;
        case 'E':*a = 'S';break;
        case 'S':*a = 'W';break;
        case 'W':*a = 'N';break;
    }
}

void go(int *x,int *y,char a)
{
    if (a=='N')
        *y+=1;
    else if(a=='S')
        *y-=1;
    else if(a=='W')
        *x-=1;
    else
        *x+=1;
}

int main(int argc, const char * argv[])
{
    int loop,x,y;
    string str;
    char faceTo;
    cin>>loop;
    while (loop--) {
        cin>>str;
        x = 0;
        y = 0;
        faceTo='N';
        for (string::iterator i = str.begin(); i!=str.end(); i++) {
//            cout<<*i<<endl;
            if (*i=='R')
                turnRight(&faceTo);
            else if(*i=='L')
                turnLeft(&faceTo);
            else
                go(&x, &y, faceTo);
//            cout<<x<<' '<<y<<' '<<faceTo<<endl;
        }
        cout<<x<<' '<<y<<' '<<faceTo<<endl;
    }
}
        