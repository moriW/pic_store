 
#include <stdio.h>

void getNumbers(int a,int *x,int *y)
{
    *x = 0;
    *y = 0;
    
    while (a) {
        if (a%2)
            (*x)++;
        else
            (*y)++;
        a /= 2;
    }
}

int main()
{
    int temp,a,b;
    long long f[242];
    f[0] = 1;
    f[1] = 1;
    for (int i = 2; i != 242; i++)
        f[i] = f[i-1] + f[i-2];
    
    while (~scanf("%d",&temp)) {
        getNumbers(temp, &a, &b);
        printf("%lld\n",f[a*b]%1314520);
    }
}
        