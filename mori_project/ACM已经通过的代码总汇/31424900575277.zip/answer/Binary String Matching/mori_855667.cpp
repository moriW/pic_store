 
//
//  main.cpp
//  Binary String Matching
//
//  Created by Moridisa on 14-5-7.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;

bool strc(char a[],char b[],int left,int right)
{
    for (int i=left,t=0; i<=right;t++,i++) {
        if (a[t]!=b[i])
            return false;
    }return true;
}

int main()
{
    int loop;
    cin>>loop;
    while (loop--) {
        char a[12],b[1002];
        scanf("%s",a);
        int n=(int)strlen(a)-1;
        scanf("%s",b);
        int sum=0;
        for (int i=n,t=0; b[i]!='\0';t++, i++) {
            if (strc(a, b, t, i))
                sum++;
        }printf("%d\n",sum);
    }
}        