 
//
//  main.cpp
//  Binary String Matching
//
//  Created by Mori.William on 15/3/14.
//  Copyright (c) 2015年 Mori.William. All rights reserved.
//

#include <iostream>
#include <string>
using namespace std;

bool jude(string a,string b,int location)
{
    if(a.length() > b.length()-location)
        return false;
    for (int i = location,j = 0; j != a.length(); j++,i++)
        if (a[j] != b[i])
            return false;
    return true;
}

int main()
{
    int loop,count;
    cin>>loop;
    string a,b;
    bool flag = true;
    while (loop--) {
        cin>>a>>b;
        count = 0;
        for (int i = 0; i != b.length(); i++) {
            flag = false;
            if (a[0] == b[i])
                flag = jude(a, b, i);
            if (flag)
                count++;
        }
        cout<<count<<endl;
    }
    return 0;
}        