 
//
//  main.cpp
//  非洲小孩
//
//  Created by Moridisa on 14-5-18.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <algorithm>

using   namespace   std;

struct time
{
    int st;
    int et;
};

bool cmp(struct time i,struct time j)
{
    if (i.et<j.et)
        return true;
    else if (i.et==j.et){
        if (i.st>j.st)
            return true;
        else
            return false;
    }
    else
        return false;
}

int main ()
{
    struct time ti[200];
    int n;
    while (cin>>n) {
        int t1,t2,t3,t4;
        for (int i=0; i<n; i++) {
            scanf("%d:%d-%d:%d",&t1,&t2,&t3,&t4);
            
            ti[i].st = t1*60+t2;
            ti[i].et = t3*60+t4;
            
            if (ti[i].et<ti[i].st)
                swap(ti[i].et,ti[i].st);
        }
        sort(ti, ti+n, cmp);
        //for (int i=0; i<n; i++)
          //  cout<<ti[i].st<<' '<<ti[i].et<<endl;
        int sum=1;
        int en=ti[0].et;
        for (int i=1; i<n; i++) {
            if (ti[i].st>en) {
                sum++;
                en=ti[i].et;
            }
        }
        cout<<sum<<endl;
    }
    return 0;
}
        