 
#include <stdio.h>

int main()
{
    long long a[41]={3,5};
    for (int i = 2; i!=41; i++)
        a[i] = a[i-1] + a[i-2];
    int loop,n;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&n);
        printf("%d\n",a[n-2]);
    }
}
        