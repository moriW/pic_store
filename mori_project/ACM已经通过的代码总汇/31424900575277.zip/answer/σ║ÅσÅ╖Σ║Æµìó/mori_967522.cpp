 
//
//  main.cpp
//  序号互换
//
//  Created by Moridisa on 14-5-19.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
using namespace std;

int main()
{
    int loop;
    cin>>loop;
    
    
    char a[100];
    while (loop--) {
        cin>>a;
        unsigned long long sum = 0;
        if (a[0]>'0'&&a[0]<='9') {
            for (int i = (int)strlen(a)-1,j = 0; i != -1; j++, i--)
                sum += pow(10, j)*(a[i]-'0');
            int t = 0;
            char b[100];
            while (sum) {
                b[t++] = (sum-1)%26+'A';
                sum = (sum-1)/26;
            }
            for (int i = t-1; i!=-1; i--)
                cout<<b[i];
            cout<<endl;
        }
        else{
            for (int i = (int)strlen(a)-1,j = 0 ; i != -1; i--,j++)
                sum += pow(26, j)*(a[i]-64);
            cout<<sum<<endl;
        }
        ;
    }
}        