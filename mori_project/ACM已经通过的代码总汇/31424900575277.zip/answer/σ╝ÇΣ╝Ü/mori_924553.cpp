 
#include <stdio.h>
#include <math.h>

long long sum(int a,int b)
{
    long long m = 1,n = 1;
    for (int i = a; i>a-b; i--)
        m*=i;
    for (int j = b; j>=1; j--)
        n*=j;
    return m/n;
}

int main()
{
    int s,n,t;
    while (scanf("%d%d",&s,&n)!=EOF) {
        while (n--) {
            scanf("%d",&t);
            printf("%lld ",sum(s, t));
            s-=t;
        }
        printf("\n");
    }
}        