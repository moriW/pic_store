 
//
//  main.cpp
//  c++萌萌哒
//
//  Created by t.y. on 15/3/12.
//  Copyright (c) 2015年 ___FULLUSERNAME__. All rights reserved.
//
//65


#include <iostream>
#include <string.h>
using namespace std;

int map[100][100];

int main()
{
    int n,value,x,y;
    cin>>n;
    value = 0;
    y = n - 1;
    x = 0;
    memset(map, 0, sizeof(map));
    if (n == 1) {
        cout<<1<<endl;
        return 0;
    }
    while (value < n*n) {
        
        for ( x ; x + 1 != n && map[x + 1][y] == 0 ; x++ )
            map[x][y] = ++value;
        for ( y ; y != 0 && map[x][y - 1] == 0 ; y-- )
            map[x][y] = ++value;
        for ( x ; x != 0 && map[x - 1][y] == 0 ; x-- )
            map[x][y] = ++value;
        for ( y ; y + 1 != n && map[x][y + 1] == 0 ; y++ )
            map[x][y] = ++value;
        
        if (x == y && map[x][y] == 0)
            map[x][y] = ++value;
    }
    
    for (int i = 0; i != n; i++) {
        for (int j = 0; j != n; j++)
            cout<<map[i][j]<<' ';
        cout<<endl;
    }
    
    return 0;
}        