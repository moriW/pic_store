 
//
//  main.c
//  蛇形填数
//
//  Created by Moridisa on 14-3-17.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>


int main()
{
    int get;
    scanf("%d",&get);
    int fuck[get][get],x=get-1,y=0,t=0;
    fuck[x][y]=0;
    if (get!=1) {
    for (int i=0; i<get-1; i++) {
            while (y<get-1-i) {
                fuck[x][y]=t+=1;
                y++;
            }while (x>i) {
                fuck[x][y]=t+=1;
                x--;
            }while (y>i) {
                fuck[x][y]=t+=1;
                y--;
            }while (x<get-2-i) {
                fuck[x][y]=t+=1;
                x++;
            }
            if (fuck[x][y]>get*get) {
                fuck[x][y]=get*get;
            }if (fuck[x][y]==0) {
                fuck[x][y]=get*get;
            }
        }
    }
    x=0,y=0;
    if(get!=1){
        while(y<get) {
        printf("%d ",fuck[x][y]);
        x++;
        if (x==get-1) {
            printf("%d\n",fuck[x][y]);
            x=0;
            y++;
            }
        }
    }else{printf("1");}
}        