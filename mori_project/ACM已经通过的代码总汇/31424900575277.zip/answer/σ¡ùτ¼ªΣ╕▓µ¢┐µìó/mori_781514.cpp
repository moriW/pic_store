 
//
//  main.c
//  字符串替换
//
//  Created by Moridisa on 14-3-23.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <string.h>

int main()
{
    char s[1000];
    while (gets(s)!=NULL) {
        for (int i=0; s[i]!='\0'; i++) {
            if (s[i]=='y'&&s[i+1]=='o'&&s[i+2]=='u') {
                printf("w");
                printf("e");
                i+=2;
            }else{printf("%c",s[i]);}
        }printf("\n");
    }
}
        