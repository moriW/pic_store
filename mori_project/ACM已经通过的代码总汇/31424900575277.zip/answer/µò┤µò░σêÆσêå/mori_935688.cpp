 
#include <stdio.h>

int main()
{
    int a[]={0,1,2,3,5,7,11,15,22,30,42},loop,n;
    scanf("%d",&loop);
    while(loop--){
        scanf("%d",&n);
        printf("%d\n",a[n]);
    }
}
        