 
#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

int main()
{
    int loop,n;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&n);
        int *a = new int[n];
        for (int i = 0; i<n ; i++)
            scanf("%d",&a[i]);
        sort(a, a+n);
        printf("%d\n",a[n/2]);
        delete [] a;
    }
    return 0;
}        