 
//
//  main.cpp
//  指数运算
//
//  Created by mori on 14-9-13.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    int a,b;
    while (cin>>a>>b){
        
        long long sum = 1;
        while (b--)
            sum *= a;
        cout<<sum<<endl;
        
    }
}        