 
//
//  main.cpp
//  大数阶乘
//
//  Created by Moridisa on 14-9-10.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

// 5000的阶乘 16326 位

#include <cstdio>
#include <cstring>
int main()
{
    int n,len,k,a[17000],b,temp,i;
    while (scanf("%d",&n)!=EOF) {
        memset(a, 0, sizeof(a));
        a[0] = 1;
        for (int i = 2; i<=n; i++) {
            k = 0;
            b = 0;
            while (k<17000) {
                temp = a[k] * i + b;
                a[k] = temp%10;
                b = temp/10;
                k++;
            }
        }
        for (i = 16999;a[i]==0; i--);
        for (i; i!=-1; i--)
            printf("%d",a[i]);
        printf("\n");
    }
}        