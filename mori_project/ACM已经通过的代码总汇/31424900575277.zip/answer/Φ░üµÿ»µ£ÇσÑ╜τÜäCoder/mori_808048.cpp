 
#include<stdio.h>

int main()
{
    int n;
    while (scanf("%d",&n)&&n!=0) {
        int a,b,c=0;
        while (n--) {
            scanf("%d%d",&a,&b);
            if (c<a+b) {
                c=a+b;
            }
        }printf("%d\n",c);
    }
}        