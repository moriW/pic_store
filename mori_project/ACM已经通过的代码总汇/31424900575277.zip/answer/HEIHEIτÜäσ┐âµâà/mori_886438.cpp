 
#include<iostream>
#include <stdlib.h>
#include <cstring>
#include <cstdio>
//from coder mori
using namespace std;

int main()
{
    int n,t,i,j;
    char s[20];
    //freopen("c.txt","r",stdin);
    cin>>n;
    int *a=(int *)malloc(sizeof(int)*n);
    for(i=0;i<n;i++){
        cin>>s;
        a[i]=t=0;
        if(strcmp(s,"Sunday")==0||strcmp(s,"Saturday")==0)
            cin>>t;
        a[i]+=t;
        for(j=0;j<2;j++){
            cin>>t;
            a[i]+=t;
        }
        //cout<<s<<' '<<a[i]<<endl;
    }
    for(int i=0;i<n;i++)
        cout<<a[i]<<endl;
}
        