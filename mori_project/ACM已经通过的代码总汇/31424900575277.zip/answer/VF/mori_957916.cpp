 
#include <cstdio>
#include <cstring>

int main()
{
    int a[84][12],n;
    memset(a,0,sizeof(a));
    for(int i = 0;i!=10;i++)
        a[0][i] = 1;
    for(int i = 1;i<82;i++){
        for(int j = 1;j<10;j++){
            for(int k = 0;k<10&&i-k>=0;k++){
                if(a[i-k][j-1])
                    a[i][j]+=a[i-k][j-1];
            }
        }
    }
    while(~scanf("%d",&n)){
        if(n==1)
            printf("10\n");
        else
            printf("%d\n",a[n][9]);
    }
}
        