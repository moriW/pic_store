 
#include <stdio.h>
#include <iostream>
#include <string.h>

using namespace std;

bool jugeaz (char a)
{
    if (a<='z'&&a>='a')
        return true;
    return false;
}

bool jugeAZ (char a)
{
    if (a<='Z'&&a>='A')
        return true;
    return false;
}

bool jugeNum(char a)
{
    if (a<='9'&&a>='0')
        return true;
    return false;
}

bool  juge_ (char a)
{
    return a=='_'?true:false;
}

int main()
{
    char a[20];
    memset(a, 0, sizeof(a));
    while (cin >> a) {
        if (jugeAZ(a[0])||jugeaz(a[0])||juge_(a[0])) {
            for (int i=1; a[i]!='\0'; i++) {
                if (jugeaz(a[i])||jugeAZ(a[i])||juge_(a[i])||jugeNum(a[i]))
                    continue;
                else{
                    //cout<<a[i]<<endl;
                    goto No;
                }
            }
        }
        else{
            cout<<"No"<<endl;
            continue;
        }
        memset(a, 0, sizeof(a));
        cout<<"Yes"<<endl;continue;
    No: cout<<"No"<<endl;
    }
}        