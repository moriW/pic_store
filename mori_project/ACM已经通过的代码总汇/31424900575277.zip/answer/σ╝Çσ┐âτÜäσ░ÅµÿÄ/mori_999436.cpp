 
//
//  main.cpp
//  开心的小明
//
//  Created by Mori.William on 14-10-9.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
using namespace std;

int main()
{
    int loop,n,m,sum,v,p,temp;
    int dp[30000];
    scanf("%d",&loop);
    while (loop--) {
        sum = 0;
        scanf("%d%d",&m,&n);
//        dp = (int *)malloc(sizeof(int)*(m+2));
        memset(dp, 0, sizeof(dp));
        
        for (int i = 0; i!=n; i++) {
            scanf("%d%d",&v,&p);
            for (int j = m; j >= v; j--) {
                temp = dp[j-v] + v * p;
                dp[j] = dp[j] > temp ? dp[j]:temp;
            }
//            for (int i = 0; i<=m; i++)
//                printf("%d ",dp[i]);
//            printf("\n");
        }
        printf("%d\n",dp[m]);
//        free(dp);
    }
    return 0;
}        