 
#include<stdio.h>
int main()
{
    int n,s,m,sum,a;
    scanf("%d",&n);
    while(n--)
    {
        scanf("%d%d",&m,&s);
        sum=s;
        while(--m)
        {
            scanf("%d",&a);
            if(s<0)
                s=a;
            else
                s+=a;
            if(s>sum)
                sum=s;
        }
        printf("%d\n",sum);
    }
}        