 
#include <cstdio>
#include <algorithm>
using namespace std;

int main()
{
    int loop,a,b,sum;
    scanf("%d",&loop);
    while(loop--){
        sum = 0;
        scanf("%d%d",&a,&b);
        sum = a/b;
        sum += a%b !=0 ? 1:0;
        printf("%d\n",sum);
    }
}
        