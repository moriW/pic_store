 
#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n,all=1;
        scanf("%d",&n);
        while (n--) {
            all=(all+1)*2;
        }printf("%d\n",all);
    }
}        