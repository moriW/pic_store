 
#include <stdio.h>
#include <math.h>

int main(void)
{
int t;
double a, b, c;

scanf("%d", &t);
while (t--) {
scanf("%lf%lf%lf", &a, &b, &c);
printf("%s\n", fabs(a + b - c) < 1.0E-4 ? "Yes" : "No");
}
return 0;
}        