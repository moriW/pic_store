 
#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int loop,n;
    cin>>loop;
    while (loop--) {
        cin>>n;
        for (int x = 1; x<=n*n*n; x++) {
            for (int y = x; y<=n*n*n; y++)
                if (x*y==x*n+y*n)
                    printf("1/%d=1/%d+1/%d\n",n,y,x);
        }
    }
}        