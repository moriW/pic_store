 
#include <iostream>
using namespace std;

int main()
{
    int loop;
    double a,b,c,d;
    cin>>loop;
    while (loop--) {
        cin>>a>>b>>c>>d;
        if (a/b>=c/d)
            cout<<"iphone 5S"<<endl;
        else
            cout<<"iphone 5C"<<endl;
    }
}        