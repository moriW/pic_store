 
//
//  main.c
//  无限网络覆盖问题
//
//  Created by Moridisa on 14-3-21.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <math.h>

int main()
{
    float loop,l,d,r,t,s;
    scanf("%f",&loop);
    while (loop--) {
        scanf("%f%f%f",&l,&d,&r);
        s=sqrtf(4*r*r-d*d);
        if (2*r>d&&s>=1) {
            t=l/s;
            printf("%.0f\n",ceilf(t));
        }else{printf("impossible\n");}
    }
}        