 
#include <stdio.h>
#include <string.h>
void    printttt(char a[],int n)
{
    for (int i=n; i>=0; i--) {
        if (a[i]>=97&&a[i]<=122) {
            printf("%c",a[i]);
        }
    }
}

int main()
{
    int loop,c,d;
    scanf("%d",&loop);
    while (loop--) {
        char a[41],b[41];
        getchar();
        scanf("%s %s",a,b);
        c=(int)strlen(a)-1;
        d=(int)strlen(b)-1;
        printttt(b, d);
        printttt(a, c);
        printf("\n");
    }
}        