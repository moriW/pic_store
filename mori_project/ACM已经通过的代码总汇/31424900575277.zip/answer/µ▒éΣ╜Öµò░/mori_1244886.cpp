 
#include <stdio.h>
#include <string.h>

int main()
{
    char number[1000000];
    int loop;
    int n;
    scanf("%d",&loop);
    while(loop--){
        memset(number,0,sizeof(number));
        scanf("%s",number);
        n = 0;
        for(int i = 0; number[i] >= '0' && number[i] <= '9';){
            int temp = 5;
            while( temp != 0 && '0' <= number[i] && number[i] <= '9' ){
                n *= 10;
                n += number[i] - '0';
                temp--;
                i++;
            }
            n %= 10003;
        }
        printf("%d\n",n);
    }
}
        