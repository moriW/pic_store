 
//
//  main.cpp
//  相反输出
//
//  Created by Mori.William on 14-9-21.
//  Copyright (c) 2014年 Mori.William. All rights reserved.
//
#include <cstdio>

int main()
{
    int a[10];
    while (~scanf("%d%d%d%d%d%d%d%d%d%d",&a[0],&a[1],&a[2],&a[3],&a[4],&a[5],&a[6],&a[7],&a[8],&a[9])) {
        for (int i = 9; i!=-1; i--)
            printf("%d ",a[i]);
        printf("\n");
    }
}        