 
#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
    long long a[16]={0};
    a[1]=0;a[2]=1;
    for (int i=3; i<16; i++)
        a[i]=(i-1)*(a[i-2]+a[i-1]);
    int n;
    while (scanf("%d",&n)!=EOF) {
        printf("%lld\n",a[n]);
    }
}        