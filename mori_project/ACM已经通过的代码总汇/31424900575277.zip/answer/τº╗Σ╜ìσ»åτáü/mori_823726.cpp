 
#include <stdio.h>

int main()
{
    char s[50];
    int t;
    while (scanf("%s%d",s,&t)!=EOF) {
        for (int i=0; s[i]!='\0'; i++) {
            printf("%c",s[i]-t<'A'?s[i]-t+26:s[i]-t);
        }printf("\n");
    }
}        