 
#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

struct thing
{
    double weighet;
    double value;
}a[10000];

bool cmp(struct thing x,struct  thing y){return (x.weighet/x.value)>(y.weighet/y.value);}

int main()
{
    double all_value,sum=0;
    int n;
    while (scanf("%lf%d",&all_value,&n)&&(all_value!=-1||n!=-1)) {
        sum = 0;
        for (int i = 0; i<n; i++)
            scanf("%lf%lf",&a[i].weighet,&a[i].value);
        
        sort(a, a+n,cmp);
        
        for (int i = 0; all_value>=0&&i<n;i++) {
            if (a[i].value == 0)
                sum += a[i].weighet;
            else if (all_value>a[i].value){
                all_value-=a[i].value;
                sum += a[i].weighet;
            }
            else{
                sum += a[i].weighet*(all_value/a[i].value);
                all_value = 0;
            }
        }
        printf("%.3lf\n",sum);
        sum = 0;
    }
    return  0;
}        