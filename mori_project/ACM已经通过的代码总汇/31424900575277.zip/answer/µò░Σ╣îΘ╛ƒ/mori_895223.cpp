 
//
//  main.cpp
//  数乌龟
//
//  Created by Moridisa on 14-6-13.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
using namespace std;

int main()
{
    long long a[57]={0,1,2,3,4};
    for (int i=5; i<57; i++)
        a[i]=a[i-1]+a[i-3];
    int n;
    while (cin>>n,n!=0) {
        cout<<a[n]<<endl;
    }
}        