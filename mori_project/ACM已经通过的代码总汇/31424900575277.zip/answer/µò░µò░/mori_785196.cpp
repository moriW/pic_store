 
#include<stdio.h>
#include<string.h>

int main()
{
	int loop;
	scanf("%d\n",&loop);
	while(loop--){
		char s[11];
		gets(s);
		int l=strlen(s);
		if(l==1&&s[0]=='0')
			printf("O\n");
		else{
			for(l;l>=0;l--){
				if((s[l]=='0'&&l!=0)||s[l]=='1')
					printf("O");
				if(s[l]=='2'||s[l]=='3')
					printf("T");
				if(s[l]=='4'||s[l]=='5')
					printf("F");
				if(s[l]=='6'||s[l]=='7')
					printf("S");
				if(s[l]=='8')
					printf("E");
				if(s[l]=='9')
					printf("N");
			}printf("\n");
		}
	}return 0;
}        