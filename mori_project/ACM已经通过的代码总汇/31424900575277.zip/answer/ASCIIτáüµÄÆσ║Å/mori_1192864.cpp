 
 
//
//  main.c
//  ASCII排序
//
//  Created by Moridisa on 14-3-16.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int t,x[4],k;
    scanf("%d\n",&k);
    char s;
    while (k--) {
        for (int i=0; i<4; i++) {
            scanf("%c",&s);
            x[i]=s;
            if (x[i]==10) {
                if(x[0]>x[1]){
                    t=x[0];
                    x[0]=x[1];
                    x[1]=t;
                }if(x[1]>x[2]){
                    t=x[1];
                    x[1]=x[2];
                    x[2]=t;
                }if(x[0]>x[1]){
                    t=x[0];
                    x[0]=x[1];
                    x[1]=t;
                }
                break;
            }
           
        }
        printf("%c %c %c\n",x[0],x[1],x[2]);
    }
}                