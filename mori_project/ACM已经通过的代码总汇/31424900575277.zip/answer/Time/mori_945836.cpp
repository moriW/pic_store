 
#include <iostream>
#include <string>

#define topyes " _ "
#define topno "   "
#define hr "  |"
#define hl "|  "
#define hd "| |"
#define hrc " _|"
#define hlc "|_ "
#define hdc "|_|"


using namespace std;

struct char_num
{
    string top;
    string mid;
    string down;
};


void ccout(char_num a)
{
    cout<<a.top<<endl<<a.mid<<endl<<a.down<<endl;
}

int main()
{
    char_num num[10];
    num[0].top  = topyes;
    num[0].mid  = hd;
    num[0].down = hdc;
    num[1].top  = topno;
    num[1].mid  = hr;
    num[1].down = hr;
    num[2].top  = topyes;
    num[2].mid  = hrc;
    num[2].down = hlc;
    num[3].top  = topyes;
    num[3].mid  = hrc;
    num[3].down = hrc;
    num[4].top  = topno;
    num[4].mid  = hdc;
    num[4].down = hr;
    num[5].top  = topyes;
    num[5].mid  = hlc;
    num[5].down = hrc;
    num[6].top  = topyes;
    num[6].mid  = hlc;
    num[6].down = hdc;
    num[7].top  = topyes;
    num[7].mid  = hr;
    num[7].down = hr;
    num[8].top  = topyes;
    num[8].mid  = hdc;
    num[8].down = hdc;
    num[9].top  = topyes;
    num[9].mid  = hdc;
    num[9].down = hrc;
    int a[4];
    while (cin>>a[0]>>a[1]>>a[2]>>a[3]) {
        for (int i = 0; i<4; i++)
            cout<<num[a[i]].top;
        cout<<endl;
        for (int i = 0; i<4; i++)
            cout<<num[a[i]].mid;
        cout<<endl;
        for (int i = 0; i<4; i++)
            cout<<num[a[i]].down;
        cout<<endl;
    }
}
        