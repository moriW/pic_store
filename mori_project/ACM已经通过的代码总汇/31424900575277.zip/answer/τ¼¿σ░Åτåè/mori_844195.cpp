 
#include <stdio.h>
#define Da(a,b) a>b?a:b
#define Xiao(a,b) a>b?b:a
int SuS(int a)
{
    int i;
    if (a<2)
        return 0;
    if (a==2)
        return 1;
    for (i=2 ; i*i<=a; i++)
        if (a%i==0)
            return 0;
    return 1;
}

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        char a[101];
        scanf("%s",a);
        int b[26]={0},i,max=0,min=200;
        for (i=0; a[i]!='\0'; i++)
            b[a[i]-97]++;
        for (i=0; i<26; i++) {
            //printf("%d ",b[i]);
            if (b[i]>0) {
                max=Da(max, b[i]);
                min=Xiao(min, b[i]);
            }
        }//printf("%d %d",max,min);
        if (SuS(max-min)) {
            printf("Lucky Word\n%d\n",max-min);
            continue;
        }printf("No Answer\n0\n");
    }
}        