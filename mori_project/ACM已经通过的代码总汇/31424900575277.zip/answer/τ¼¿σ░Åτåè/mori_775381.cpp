 
//
//  main.c
//  笨小熊
//
//  Created by Moridisa on 14-3-20.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int repi(char a[],int n)
{
    int max[110]={0},i,j;
    for (i=0; i<n; i++) {
        for (j=0; j<n; j++) {
            if (a[i]==a[j]) {
                max[i]++;
            }
        }
    }for (j=0; j<n; j++){
        for (i=j+1; i<n; i++){
            if (max[j]>max[i]){
                int b;
                b=max[i];
                max[i]=max[j];
                max[j]=b;
            }
        }
    }int k;
    k=max[n-1]-max[0];
    if (k==1) {
        return 0;
    }if (k==2) {
        return 2;
    }if (k==3) {
        return 3;
    }else{
        for (int i=2; i<k; i++) {
            if (k%i==0) {
                return 0;
            }
        }
    }return k;
}

int main()
{
    int loop,k=0,x;
    char s[120];
    scanf("%d",&loop);
    while (loop--) {
        k=0;
        scanf("%s",s);
        for (int i=0;s[i]!='\0'; i++) {
            k++;
        }x=repi(s, k);
        if (x!=0) {
            printf("Lucky Word\n%d\n",x);
        }if (x==0) {
            printf("No Answer\n0\n");
        }
    }
}        