 
//
//  main.c
//  n-1位数
//
//  Created by Moridisa on 14-3-22.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
int main()
{
    int loop,w,z,x=0;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&w);
        for (x=1; x<w; x*=10) {
            if (w/x==0) {
                break;
            }
        }
        z=w%(x/10);
        printf("%d\n",z);
    }
}        