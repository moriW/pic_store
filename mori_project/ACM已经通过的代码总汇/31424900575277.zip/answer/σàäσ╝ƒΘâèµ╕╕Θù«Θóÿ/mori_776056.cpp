 
//
//  main.c
//  兄弟郊游
//
//  Created by Moridisa on 14-3-21.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    float loop,x,y,z,m,sDog,t;
    scanf("%f",&loop);
    while (loop--) {
        scanf("%f%f%f%f",&m,&x,&y,&z);
        t=(x*m)/(y-x);
        sDog=z*t;
        printf("%.2f\n",sDog);
    }
}        