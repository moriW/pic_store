 
#include <stdio.h>


int main()
{
    
    int a[20]={2,4,11,31,83,227,616,1674,4550,12367,33617,91380,248397,675214,1835421,4989191},loop,n;
    scanf("%d",&loop);
    while (loop--) {
        scanf("%d",&n);
        printf("%d\n",a[n-1]);
    }
    
}        