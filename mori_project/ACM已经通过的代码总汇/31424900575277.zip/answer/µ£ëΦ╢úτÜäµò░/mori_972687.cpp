 
//
//  main.cpp
//  有趣的数
//
//  Created by mori on 14-9-13.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
using namespace std;
int main(int argc, const char * argv[])
{
    int a[449]={0,1},n,loop,up,down;
    for (int i = 2; i!=449; i++)
        a[i] = a[i-1] + i;
    cin>>loop;
    while (loop--) {
        cin>>n;
        int i;
        for (i = 0; a[i]<n; i++);
        up = n - a[i-1];
        down = i + 1 - up;
        if (i%2==0)
            cout<<up<<'/'<<down<<endl;
        else
            cout<<down<<'/'<<up<<endl;
    }
}
        