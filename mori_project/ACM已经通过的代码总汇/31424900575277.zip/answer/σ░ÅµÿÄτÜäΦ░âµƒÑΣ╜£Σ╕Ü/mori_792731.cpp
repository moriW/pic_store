 
#include <stdio.h>

void maop(int s[],int n)
{
    for (int i=0; i<n; i++) {
        for (int j=i+1; j<n; j++) {
            if (s[i]>s[j]) {
                s[i]+=s[j];
                s[j]=s[i]-s[j];
                s[i]-=s[j];
            }
        }
    }
}



int main()
{
    int n;
    while(scanf("%d",&n)!=EOF){
        int a[n],t=0;
        for (int i=0; i<n; i++) {
            scanf("%d",&a[i]);
        }maop(a, n);
        for (int i=0; i<n; i++) {
            for (int j=i+1; j<n; j++) {
                if (a[i]==a[j]) {
                    a[j]=-1;
                }
            }
        }
        for (int i=0; i<n; i++) {
            if (a[i]!=-1) {
                t++;
            }
        }printf("%d\n",t);
        for (int i=0; i<n; i++) {
            if (a[i]!=-1) {
                printf("%d ",a[i]);
            }
        }printf("\n");
    }
}        