 
//
//  main.c
//  韩信点兵
//
//  Created by Moridisa on 14-3-18.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int p=100,a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    while(p--){
        if (p%3==a&&p%5==b&&p%7==c) {
            printf("%d",p);
            break;
        }if (p<10) {
            printf("No answer");
            break;
        }
    }
}
        