 
#include<iostream>
#include<stdio.h>
using namespace std;
int a[1000000];
int b[1000000];
int main()
{
    int c[7],n(0),m(0),t,flag(0),five(0),two(0),one(0);
    for(int i=125;i!=1000000;++i)
    {
        t=i;
        for(int k=0;t!=0;++k,++flag)
        {
            c[k]=t%10;
            t=t/10;
        }
        for(int k=0;k!=flag;k++)
        {
            if(c[k]==5) {++five;continue;}
            if(c[k]==2) {++two;continue;}
            if(c[k]==1) ++one;
        }
        
        if(five!=0&&two!=0&&one!=0)
        {
            ++n;
            a[i]=n;
        }
        else a[i]=n;
        
        b[i]=m;
        for(int j=0;j!=flag-2;++j)
        {
            if(c[j]==1&&c[j+1]==2&&c[j+2]==5)
            {
                ++m;
                b[i]=m;
                break;
            }
        }
        flag=0;
        five=0;
        two=0;
        one=0;
    }
    //for(int i=0;i<=250;++i)
    //  cout<<i<<" "<<a[i]<<endl;
    n=0;
    int a1,b1;
    while(cin>>a1>>b1)
    {
        ++n;
        printf("Case %d:%d %d\n",n,a[b1]-a[a1-1],b[b1]-b[a1-1]);
    }
    return 0;
}        