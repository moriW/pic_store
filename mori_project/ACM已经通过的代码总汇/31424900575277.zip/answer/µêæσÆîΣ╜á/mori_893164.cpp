 
#include<stdio.h>
#include<string.h>

char a[310];
char b[4];

int n=strlen("你");
int main()
{
int i,j;
while(scanf("%s",a),strcmp(a,"0"))
{
for(i=0;i<strlen(a);)
{
for(j=0;j<n;j++)
b[j]=a[i+j];
b[j]='\0';
if(!strcmp(b,"你"))
{
printf("我");
i+=n;
}
else if(!strcmp(b,"我"))
{
printf("你");
i+=n;
}
else
{
printf("%c",a[i]);
i++;
}
}
printf("\n");
}
return 0;
}
        