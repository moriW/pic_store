 
 
#include <iostream>
#include<math.h>
using namespace std;
bool vis[1000010];
int main()
{
	int n=1000010;
	int m =sqrt(n+0.5);
	int c=0;
	for(int i =2;i<=m;i++)
		if(!vis[i])
		{
			for (int j = i*i;j<=n;j+=i) 
				vis[j]=1; 
		}
	cin>>n;
	while(n--)
	{
		int count=0,m;
		cin>>m;
		for(int i=3;i<m-1;i++)
		{
			if(!vis[i] && !vis[i+2]) count++;
		}
		if(m>3)
			cout<<count+1<<endl;
		else if(m==3) cout<<"1"<<endl;
		else cout<<"0"<<endl;
	}
	
		return 0;
}                