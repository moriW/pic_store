 
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;

bool a[1000001];
int main()
{
    memset(a, true, sizeof(a));
    for (int i = 2; i!=1000000; i++) {
        for (int j = 2*i; j<=1000000; j+=i) {
            a[j] = false;
        }
    }
    
    int loop,n,sum;
    cin>>loop;
    while (loop--) {
        cin>>n;
        sum = 0;
        for (int i = n; i>=3; i--) {
            if (a[i]&&a[i-2]) {
                sum++;
            }
        }
        cout<<sum<<endl;
    }
    
}        