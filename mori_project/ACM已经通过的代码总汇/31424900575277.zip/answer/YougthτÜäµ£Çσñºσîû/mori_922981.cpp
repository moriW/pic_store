 

//
//  main.cpp
//
//
//  Created by Moridisa on 14-3-17.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#define left true
#define right false
using namespace std;
struct thing
{
    double wi,vi;
}a[10005];

bool cmp(double x,double y)
{return x>y;}

bool left_right(double mid,int n,int m)
{
    double p[10005],sum = 0;
    for (int i = 0; i < n; i++)
        p[i] = a[i].vi - a[i].wi*mid;
    sort(p, p+n,cmp);
    for (int i = 0; i < m; i++)
        sum += p[i];
    return sum>=0;
}

int main()
{
    int n,m;
    double l,max,mid;
    while (cin>>n>>m) {
        l = max = 0;
        for (int i = 0; i<n ; i++){
            scanf("%lf%lf",&a[i].wi,&a[i].vi);
            if ((a[i].vi/a[i].wi)>max)
                max = (a[i].vi/a[i].wi);
        }
        
        while (max-l>=0.000001) {
            mid = (l+max)/2;
            if (left_right(mid, n,m))
                l = mid;
            else
                max = mid;
        }
        printf("%.2lf\n",max);
        memset(a, 0, sizeof(a));
    }
}        