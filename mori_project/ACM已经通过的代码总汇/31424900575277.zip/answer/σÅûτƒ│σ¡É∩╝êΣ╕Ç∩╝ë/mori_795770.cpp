 
#include<stdio.h>
int main(){
    int num;
    scanf("%d",&num);
    while(num--){
        int a,b;
        scanf("%d%d",&a,&b);
        if(b>a){
            printf("%s\n","Win");
        }else{
            printf("%s\n",a%(b+1)==0?"Lose":"Win");
        }
    }
}        