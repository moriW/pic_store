 
#include <stdio.h>

int main()
{

        long long a,b;
        while(scanf("%lld%lld",&a,&b)!=EOF){
                if(a * b > 0)
                        printf("Signs are not opposot\n");
                else if(a * b < 0)
                        printf("Signs are opposite\n");
                else 
                        printf("Signs can't be sure\n");

        }
        return 0;
}
        