 
#include <stdio.h>

int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        long long a;
        scanf("%lld",&a);
        printf("%lld\n",(a-1)*1000+471);
    }
}        