 
#include <stdio.h>
#include <math.h>

double abs(double a)
{
    if (a<0)
        a*=-1;
    return a;
}

int main()
{
    char a[8];
    double x1,x2,y1,y2,x,y;
    while(scanf("%c %c %c %c\n%c %c %c %c",&a[0],&a[1],&a[2],&a[3],&a[4],&a[5],&a[6],&a[7],&a[8])!=EOF){
        getchar();
        x1=0;x2=0;y1=0;y2=0;x=0;y=0;
        for (int i = 0; i<8; i++) {
            if (i<4) {
                if (a[i]=='W')
                    y1++;
                else if (a[i]=='E')
                    y1--;
                else if (a[i]=='S')
                    x1++;
                else if (a[i]=='N')
                    x1--;
            } else {
                if (a[i]=='W')
                    y2++;
                else if (a[i]=='E')
                    y2--;
                else if (a[i]=='S')
                    x2++;
                else if (a[i]=='N')
                    x2--;
            }
        }
        
        double sum = 0;
        x = x1-x2;
        y = y1-y2;
        
        sum += x*x + y*y;
        printf("%.2lf\n",sqrt(sum));
    }
}        