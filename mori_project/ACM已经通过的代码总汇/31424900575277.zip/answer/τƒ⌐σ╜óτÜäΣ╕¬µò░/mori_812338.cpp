 
//
//  main.c
//  矩形个数
//
//  Created by Moridisa on 14-4-13.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>

int main()
{
    int h,w;
    while (scanf("%d%d",&h,&w)!=EOF) {
        long long sum=0;
        for (int i=1; i<=h; i++) {
            for (int j=1; j<=w; j++) {
                sum+=i*j;
            }
        }printf("%lld\n",sum);
    }
}        