 
//
//  main.c
//  车牌号
//
//  Created by Moridisa on 14-4-12.
//  Copyright (c) 2014年 Moridisa. All rights reserved.
//

#include <stdio.h>
#include <string.h>
int main()
{
    int loop;
    scanf("%d",&loop);
    while (loop--) {
        int n;
        scanf("%d",&n);
        char s[n][6],k[6]="zzzzz";
        for (int i=0; i<n; i++){
            scanf("%s",s[i]);
            if (strcmp(k, s[i])>0) {
                strcpy(k, s[i]);
            }
        }printf("%s\n",k);
    }
}        